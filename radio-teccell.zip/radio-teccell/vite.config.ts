import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  build: {
    rollupOptions: {
      input: {
        controle: path.resolve(__dirname, 'index.html'),
        player: path.resolve(__dirname, 'player.html'),
      },
    },
  },
});
