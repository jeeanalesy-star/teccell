# Rádio TecCell — Rádio Indoor (versão Netlify)

Com este sistema você controla a rádio da loja **pelo celular** e o **notebook** toca a rádio. Tudo fica salvo na nuvem do próprio Netlify, no **Netlify Blobs**, que é grátis e não precisa de Firebase.

| Endereço | Onde abrir | Para quê |
|---|---|---|
| `https://SEU-SITE.netlify.app/` | Celular | Controle: rádio, volumes, vinhetas, agendador, avisos |
| `https://SEU-SITE.netlify.app/player` | Notebook da loja | Toca o som e executa os comandos |

Os comandos chegam ao notebook em cerca de 1 segundo.

---

## 1. Publicar no Netlify (só na primeira vez)

> ⚠️ O **Netlify Drop** (arrastar a pasta para o site) **não funciona** aqui. Ele não publica as funções da nuvem. Use uma das opções abaixo.

### Opção A — GitHub (recomendado)
1. Crie um repositório no GitHub e envie esta pasta inteira para ele.
2. No Netlify, clique em **Add new project → Import an existing project → GitHub** e escolha o repositório.
3. Não mude nada nas configurações: o arquivo `netlify.toml` já define tudo. Clique em **Deploy**.

### Opção B — Pelo computador (Netlify CLI)
```bash
npm install
npx netlify-cli login
npx netlify-cli deploy --build --prod
```

O banco (Netlify Blobs) é criado sozinho no primeiro uso. Não há nada para configurar.

## 2. Primeiro acesso pelo celular
1. Abra o endereço do site no celular.
2. Digite um **PIN** de 4 a 12 números. **O primeiro PIN digitado fica cadastrado** como senha do controle.
3. Dica: no Chrome, use **"Adicionar à tela inicial"** para ter um ícone de app.
4. Para trazer suas rádios e vinhetas antigas, vá em **Ferramentas → Importar do sistema antigo**.

> Esqueceu o PIN? No Netlify, vá em *Project configuration → Environment variables*, crie a variável `RADIO_PIN` com um PIN novo e faça um novo deploy. Enquanto essa variável existir, ela é o PIN que vale.

## 3. Configurar o notebook da rádio
1. Abra `https://SEU-SITE.netlify.app/player` no Chrome e **clique uma vez** na tela. O navegador só libera o som depois de um clique.
2. Deixe a aba aberta e o notebook ligado na tomada. Desative a suspensão em *Configurações → Energia*.

**Para ligar sozinho sem precisar do clique**, crie um atalho do Chrome com este destino (Windows):
```
"C:\Program Files\Google\Chrome\Application\chrome.exe" --autoplay-policy=no-user-gesture-required --kiosk https://SEU-SITE.netlify.app/player
```
Coloque esse atalho na pasta *Inicializar* do Windows (`Win + R` → `shell:startup`). Assim a rádio abre em tela cheia quando o notebook liga. Para sair do modo kiosk, use `Alt + F4`.

## O que dá para fazer pelo celular
- Tocar, parar e trocar a rádio online, e guardar suas estações favoritas
- Ajustar o volume da rádio, o volume das vinhetas e o volume da rádio enquanto uma vinheta toca
- Enviar vinhetas (MP3/M4A/WAV até 5 MB) ou **gravar uma vinheta com a sua voz**
- Tocar uma vinheta na hora, ou parar a que está tocando
- Digitar um **aviso** para o notebook falar (ex.: "seu aparelho está pronto")
- Usar o agendador automático: intervalo, ordem da fila, o que entra na rotação e "tocar a próxima agora"
- Ver se o notebook está ligado e o que está tocando
- Recarregar o notebook à distância, caso ele trave

## Custos (plano grátis do Netlify)
O plano grátis dá **300 créditos por mês**. Estimativa para uso normal da loja, com o notebook ligado cerca de 12 h por dia e o celular aberto de vez em quando:
- Sincronização (requisições): cerca de 15 a 30 créditos/mês
- Cada **deploy** (publicação nova): **15 créditos**. Evite publicar muitas vezes por mês.
- O áudio da rádio vem direto da emissora e **não** gasta créditos. As vinhetas são baixadas **uma única vez** e depois ficam guardadas no notebook.

Para acompanhar, veja *Usage & billing* no painel do Netlify.

## Estrutura técnica
```
shared/            estado da rádio + todas as ações (usado pelo site e pelas funções)
netlify/functions  /api/action (comandos) e /api/audio (enviar/baixar vinhetas)
netlify/edge-functions/poll.ts  /api/poll — sincronização em tempo real (long polling)
src/control        app do celular
src/player         app do notebook (motor de áudio: reconexão automática, fila, abaixa a rádio na vinheta, agendador)
```
Banco: Netlify Blobs. O store `radio` guarda as chaves `state`, `player` e `auth`. O store `audios` guarda um arquivo por vinheta.

Para rodar no computador: `npm install` e depois `npm run dev`. Esse comando usa o `netlify dev`, que simula as funções e o Blobs.
