import { useCallback, useEffect, useRef, useState } from 'react';
import { Header } from '../components/Header.tsx';
import { StreamPlayer } from '../components/StreamPlayer.tsx';
import { AnnounceSection } from '../components/AnnounceSection.tsx';
import { CartucheiraSection } from '../components/CartucheiraSection.tsx';
import { AgendadoresSection } from '../components/AgendadoresSection.tsx';
import { PinGate } from '../components/PinGate.tsx';
import { ToolsSection } from '../components/ToolsSection.tsx';
import { AuthError, RadioSync, pinStore, sendAction, uploadAudio } from '../lib/api.ts';
import type { Action } from '../../shared/reducer.ts';
import type { PlayerHeartbeat, RadioState } from '../../shared/state.ts';
import { MAX_UPLOAD_BYTES } from '../../shared/state.ts';

export type Act = (a: Action) => Promise<boolean>;

export default function ControlApp() {
  const [pin, setPin] = useState(pinStore.get());
  const [state, setState] = useState<RadioState | null>(null);
  const [player, setPlayer] = useState<PlayerHeartbeat | null>(null);
  const [online, setOnline] = useState(true);
  const [toast, setToast] = useState<{ text: string; error?: boolean } | null>(null);
  const [uploading, setUploading] = useState<string | null>(null);
  const [, setClock] = useState(0);
  const syncRef = useRef<RadioSync | null>(null);
  const toastTimer = useRef<number | undefined>(undefined);

  if (!syncRef.current) {
    syncRef.current = new RadioSync({
      onState: setState,
      onPlayer: setPlayer,
      onConnection: setOnline,
    });
  }
  const sync = syncRef.current;

  useEffect(() => {
    if (!pin) return;
    sync.start();
    const t = window.setInterval(() => setClock((c) => c + 1), 1000);
    return () => {
      sync.stop();
      window.clearInterval(t);
    };
  }, [pin, sync]);

  const showToast = useCallback((text: string, error = false) => {
    window.clearTimeout(toastTimer.current);
    setToast({ text, error });
    toastTimer.current = window.setTimeout(() => setToast(null), error ? 4500 : 1800);
  }, []);

  const logout = useCallback((msg?: string) => {
    pinStore.clear();
    setPin('');
    if (msg) showToast(msg, true);
  }, [showToast]);

  const act: Act = useCallback(
    async (a: Action) => {
      try {
        const resp = await sendAction(a);
        sync.accept(resp);
        showToast('Enviado ✓');
        return true;
      } catch (err) {
        if (err instanceof AuthError) logout(err.message);
        else showToast((err as Error).message || 'Sem conexão. Tente de novo.', true);
        return false;
      }
    },
    [sync, showToast, logout],
  );

  const upload = useCallback(
    async (files: { blob: Blob; name: string }[]) => {
      let ok = 0;
      for (const [i, f] of files.entries()) {
        if (f.blob.size > MAX_UPLOAD_BYTES) {
          showToast(`"${f.name}" passa de 5 MB. Use um MP3 mais leve.`, true);
          continue;
        }
        setUploading(`Enviando ${i + 1}/${files.length}: ${f.name}`);
        try {
          const resp = await uploadAudio(f.blob, f.name);
          sync.accept(resp);
          ok++;
        } catch (err) {
          if (err instanceof AuthError) {
            logout(err.message);
            break;
          }
          showToast(`Erro ao enviar "${f.name}": ${(err as Error).message}`, true);
        }
      }
      setUploading(null);
      if (ok > 0 && ok === files.length) showToast(ok > 1 ? `${ok} vinhetas salvas na nuvem ✓` : 'Vinheta salva na nuvem ✓');
    },
    [sync, showToast, logout],
  );

  if (!pin) {
    return (
      <PinGate
        onSubmit={async (p) => {
          try {
            const resp = await sendAction({ type: 'auth' }, p);
            pinStore.set(p);
            sync.accept(resp);
            setPin(p);
            if (resp.created) showToast('PIN criado! Guarde-o bem.');
            return null;
          } catch (err) {
            return (err as Error).message || 'Sem conexão.';
          }
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#141414] text-[#F4F4F2] p-3 sm:p-6 pb-24 flex justify-center">
      <div className="w-full max-w-[1150px] flex flex-col gap-4 sm:gap-5">
        <Header player={player} online={online} serverNow={sync.serverNow()} />

        {!state ? (
          <div className="text-center text-[#8A8D91] py-16">Carregando a rádio…</div>
        ) : (
          <>
            <StreamPlayer state={state} act={act} />
            <AnnounceSection act={act} onUploadRecording={(blob, name) => upload([{ blob, name }])} />
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-5 items-start">
              <div className="lg:col-span-7">
                <CartucheiraSection state={state} act={act} onUpload={upload} uploading={uploading} />
              </div>
              <div className="lg:col-span-5">
                <AgendadoresSection state={state} act={act} serverNow={sync.serverNow()} />
              </div>
            </div>
            <ToolsSection act={act} upload={upload} onLogout={() => logout()} showToast={showToast} />
          </>
        )}

        <footer className="pt-4 border-t border-[#8A8D91]/15 text-center text-xs text-[#8A8D91] flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="font-sora font-semibold text-[#F4F4F2]">
            Tec<span className="text-[#C8102E]">C</span>ell
            <span className="text-[#8A8D91] font-normal font-inter ml-1.5">• Sua tecnologia em boas mãos.</span>
          </div>
          <div className="text-[11px]">Desde 2014 em Oriximiná • Rádio Indoor</div>
        </footer>
      </div>

      {toast && (
        <div
          className={`fixed bottom-5 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-xl text-sm font-semibold shadow-2xl border max-w-[92vw] text-center ${
            toast.error ? 'bg-[#C8102E] border-[#C8102E] text-[#F4F4F2]' : 'bg-[#242424] border-[#8A8D91]/40 text-[#F4F4F2]'
          }`}
        >
          {toast.text}
        </div>
      )}
    </div>
  );
}
