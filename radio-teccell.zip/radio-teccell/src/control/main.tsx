import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import ControlApp from './ControlApp.tsx';
import '../index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ControlApp />
  </StrictMode>,
);
