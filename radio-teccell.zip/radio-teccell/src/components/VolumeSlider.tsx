import { useEffect, useRef, useState } from 'react';
import { Volume2 } from 'lucide-react';

interface Props {
  label: string;
  value: number;
  onCommit: (v: number) => void;
}

/** Slider que mostra o valor na hora e só envia ao soltar (ou após uma pausa), economizando requisições. */
export const VolumeSlider = ({ label, value, onCommit }: Props) => {
  const [local, setLocal] = useState(value);
  const dragging = useRef(false);
  const timer = useRef<number | undefined>(undefined);

  useEffect(() => {
    if (!dragging.current) setLocal(value);
  }, [value]);

  const commit = (v: number) => {
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => {
      dragging.current = false;
      if (Math.abs(v - value) > 0.001) onCommit(v);
    }, 350);
  };

  return (
    <div className="flex items-center gap-3 text-xs text-[#8A8D91]">
      <Volume2 className="w-4 h-4 shrink-0" />
      <span className="shrink-0 font-medium w-24">{label}</span>
      <input
        type="range"
        min="0"
        max="1"
        step="0.05"
        value={local}
        onChange={(e) => {
          dragging.current = true;
          const v = parseFloat(e.target.value);
          setLocal(v);
          commit(v);
        }}
        className="w-full h-2 bg-[#141414] rounded-lg appearance-none cursor-pointer accent-[#C8102E]"
      />
      <span className="font-mono text-[#F4F4F2] w-9 text-right font-medium">{Math.round(local * 100)}%</span>
    </div>
  );
};
