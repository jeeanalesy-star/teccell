import { useEffect, useState } from 'react';
import { Play, Square, Star, Radio, Trash2, TriangleAlert } from 'lucide-react';
import type { RadioState } from '../../shared/state.ts';
import type { Act } from '../control/ControlApp.tsx';
import { VolumeSlider } from './VolumeSlider.tsx';

interface Props {
  state: RadioState;
  act: Act;
}

export const StreamPlayer = ({ state, act }: Props) => {
  const { stream, favorites, volumes } = state;
  const [url, setUrl] = useState(stream.url);
  const [name, setName] = useState(stream.name);
  const [editing, setEditing] = useState(false);

  // Mantém os campos iguais ao que está salvo, a não ser que o usuário esteja digitando
  useEffect(() => {
    if (!editing) {
      setUrl(stream.url);
      setName(stream.name);
    }
  }, [stream.url, stream.name, editing]);

  const insecure = url.trim().startsWith('http://');

  const play = async () => {
    if (!url.trim()) return;
    if (await act({ type: 'play', url: url.trim(), name: name.trim() })) setEditing(false);
  };

  return (
    <section className="bg-[#1c1c1c] rounded-2xl p-4 sm:p-5 border border-[#8A8D91]/20 shadow-xl space-y-4">
      <div className="flex items-center justify-between gap-2">
        <h2 className="font-sora text-base sm:text-lg font-bold flex items-center gap-2 tracking-tight">
          <span className="w-2.5 h-2.5 rounded-full bg-[#C8102E]" />
          Rádio online
        </h2>
        <span
          className={`text-[11px] font-bold px-2.5 py-1 rounded-full border font-sora tracking-wider ${
            stream.playing ? 'bg-[#C8102E] border-[#C8102E] text-[#F4F4F2]' : 'border-[#8A8D91]/30 text-[#8A8D91]'
          }`}
        >
          {stream.playing ? 'TOCANDO' : 'PARADA'}
        </span>
      </div>

      <div className="flex flex-col md:flex-row gap-2.5">
        <input
          type="url"
          inputMode="url"
          value={url}
          onChange={(e) => {
            setEditing(true);
            setUrl(e.target.value);
          }}
          placeholder="URL do stream (ex: https://stream.zeno.fm/...)"
          className="flex-1 px-3.5 py-3 rounded-xl bg-[#141414] border border-[#8A8D91]/30 focus:border-[#C8102E] focus:outline-none text-sm placeholder:text-[#8A8D91]/60 font-mono"
        />
        <input
          type="text"
          value={name}
          onChange={(e) => {
            setEditing(true);
            setName(e.target.value);
          }}
          placeholder="Nome da estação (opcional)"
          className="w-full md:w-52 px-3.5 py-3 rounded-xl bg-[#141414] border border-[#8A8D91]/30 focus:border-[#C8102E] focus:outline-none text-sm placeholder:text-[#8A8D91]/60"
        />
      </div>

      {insecure && (
        <div className="text-xs text-amber-300 bg-amber-500/10 border border-amber-500/30 rounded-lg p-2.5 flex gap-2">
          <TriangleAlert className="w-4 h-4 shrink-0" />
          Links que começam com <b>http://</b> costumam ser bloqueados pelo navegador. Prefira o link <b>https://</b> da rádio.
        </div>
      )}

      <div className="grid grid-cols-2 sm:flex gap-2">
        <button
          onClick={play}
          className="col-span-2 sm:col-span-1 sm:flex-none px-5 py-3 bg-[#C8102E] hover:bg-[#b00d27] active:bg-[#960a20] font-sora font-semibold rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#C8102E]/25"
        >
          <Play className="w-4 h-4 fill-current" />
          {stream.playing && url.trim() === stream.url ? 'Reiniciar rádio' : 'Tocar no notebook'}
        </button>
        <button
          onClick={() => act({ type: 'stop' })}
          disabled={!stream.playing}
          className="px-5 py-3 bg-[#242424] hover:bg-[#2e2e2e] border border-[#8A8D91]/40 font-sora font-semibold rounded-xl text-sm flex items-center justify-center gap-2 disabled:opacity-40"
        >
          <Square className="w-4 h-4 fill-current text-[#C8102E]" />
          Parar
        </button>
        <button
          onClick={() => url.trim() && act({ type: 'favAdd', url: url.trim(), name: name.trim() })}
          className="px-3.5 py-3 bg-[#141414] hover:bg-[#242424] border border-[#8A8D91]/30 font-medium rounded-xl text-sm flex items-center justify-center gap-1.5"
        >
          <Star className="w-4 h-4" /> Favoritar
        </button>
      </div>

      <div className="space-y-3 pt-3 border-t border-[#8A8D91]/20">
        <VolumeSlider label="Volume rádio" value={volumes.stream} onCommit={(v) => act({ type: 'volume', stream: v })} />
        <VolumeSlider
          label="Rádio na vinheta"
          value={volumes.duck}
          onCommit={(v) => act({ type: 'volume', duck: v })}
        />
      </div>

      <div className="pt-3 border-t border-dashed border-[#8A8D91]/20 space-y-2.5">
        <div className="flex items-center justify-between text-xs font-semibold text-[#8A8D91]">
          <span className="flex items-center gap-1.5 text-[#F4F4F2]">
            <Star className="w-3.5 h-3.5 text-[#C8102E]" /> Estações salvas (toque para sintonizar)
          </span>
          {favorites.length > 0 && (
            <button
              onClick={() => confirm('Apagar todas as rádios favoritas?') && act({ type: 'favClear' })}
              className="text-[11px] hover:text-[#C8102E] bg-[#141414] border border-[#8A8D91]/20 px-2.5 py-0.5 rounded flex items-center gap-1"
            >
              <Trash2 className="w-3 h-3" /> Zerar
            </button>
          )}
        </div>

        {favorites.length === 0 ? (
          <div className="text-xs text-[#8A8D91] italic py-1">
            Nenhuma rádio favoritada. Cole uma URL acima e toque em Favoritar.
          </div>
        ) : (
          <div className="flex flex-wrap gap-2">
            {favorites.map((fav) => {
              const active = stream.url === fav.url && stream.playing;
              return (
                <div
                  key={fav.id}
                  onClick={() => {
                    setEditing(false);
                    void act({ type: 'play', url: fav.url, name: fav.name });
                  }}
                  className={`flex items-center gap-2 pl-3.5 pr-1.5 py-2 rounded-xl text-xs font-medium cursor-pointer border ${
                    active
                      ? 'bg-[#141414] border-[#C8102E] ring-1 ring-[#C8102E]/30'
                      : 'bg-[#141414] text-[#8A8D91] hover:text-[#F4F4F2] border-[#8A8D91]/30'
                  }`}
                >
                  <Radio className={`w-3.5 h-3.5 ${active ? 'text-[#C8102E] animate-pulse' : ''}`} />
                  <span className="font-semibold">{fav.name}</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (confirm(`Remover "${fav.name}"?`)) void act({ type: 'favDel', id: fav.id });
                    }}
                    className="p-1.5 hover:text-[#C8102E] rounded"
                    title="Excluir rádio"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
};
