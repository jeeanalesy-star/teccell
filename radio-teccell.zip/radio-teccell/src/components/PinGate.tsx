import { useState, type FormEvent } from 'react';
import { Lock, LoaderCircle } from 'lucide-react';

interface Props {
  onSubmit: (pin: string) => Promise<string | null>;
}

export const PinGate = ({ onSubmit }: Props) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (pin.length < 4) return setError('O PIN precisa ter pelo menos 4 números.');
    setBusy(true);
    setError(await onSubmit(pin));
    setBusy(false);
  };

  return (
    <div className="min-h-screen bg-[#141414] text-[#F4F4F2] flex items-center justify-center p-5">
      <form onSubmit={submit} className="w-full max-w-sm bg-[#1c1c1c] border border-[#8A8D91]/20 rounded-2xl p-6 space-y-5 shadow-2xl">
        <div className="text-center space-y-2">
          <div className="font-sora font-black text-3xl tracking-tighter">
            t<span className="text-[#C8102E]">c</span>
          </div>
          <h1 className="font-sora text-xl font-bold">Rádio TecCell</h1>
          <p className="text-xs text-[#8A8D91]">
            Digite o PIN do controle. No primeiro acesso, o PIN que você digitar será cadastrado.
          </p>
        </div>
        <div className="relative">
          <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#8A8D91]" />
          <input
            autoFocus
            type="password"
            inputMode="numeric"
            autoComplete="current-password"
            value={pin}
            onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 12))}
            placeholder="PIN"
            className="w-full pl-10 pr-3 py-3.5 rounded-xl bg-[#141414] border border-[#8A8D91]/30 focus:border-[#C8102E] focus:outline-none text-lg tracking-[0.4em] font-mono"
          />
        </div>
        {error && <div className="text-xs text-[#C8102E] font-semibold text-center">{error}</div>}
        <button
          disabled={busy}
          className="w-full py-3.5 rounded-xl bg-[#C8102E] hover:bg-[#b00d27] font-sora font-semibold flex items-center justify-center gap-2 disabled:opacity-60"
        >
          {busy && <LoaderCircle className="w-4 h-4 animate-spin" />} Entrar
        </button>
      </form>
    </div>
  );
};
