import { useEffect, useRef, useState } from 'react';
import { Mic, Square, Check, X, AlertCircle, RotateCcw } from 'lucide-react';

interface Props {
  onSave: (blob: Blob, name: string) => void;
  onClose: () => void;
}

function pickMime() {
  const options = ['audio/webm;codecs=opus', 'audio/mp4', 'audio/webm', 'audio/ogg;codecs=opus'];
  if (typeof MediaRecorder === 'undefined') return '';
  return options.find((m) => MediaRecorder.isTypeSupported?.(m)) || '';
}

export const MicrophoneRecorder = ({ onSave, onClose }: Props) => {
  const [recording, setRecording] = useState(false);
  const [blob, setBlob] = useState<Blob | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [name, setName] = useState('Aviso gravado TecCell');
  const [error, setError] = useState<string | null>(null);
  const [seconds, setSeconds] = useState(0);
  const recRef = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);
  const timer = useRef<number | undefined>(undefined);

  useEffect(
    () => () => {
      window.clearInterval(timer.current);
      recRef.current?.stream.getTracks().forEach((t) => t.stop());
    },
    [],
  );

  useEffect(() => () => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
  }, [previewUrl]);

  const start = async () => {
    setError(null);
    setBlob(null);
    setPreviewUrl(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
      const mime = pickMime();
      const rec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
      chunks.current = [];
      rec.ondataavailable = (e) => e.data.size > 0 && chunks.current.push(e.data);
      rec.onstop = () => {
        const type = (rec.mimeType || mime || 'audio/webm').split(';')[0];
        const b = new Blob(chunks.current, { type });
        setBlob(b);
        setPreviewUrl(URL.createObjectURL(b));
        stream.getTracks().forEach((t) => t.stop());
      };
      recRef.current = rec;
      rec.start();
      setRecording(true);
      setSeconds(0);
      const startedAt = Date.now();
      timer.current = window.setInterval(() => {
        const s = Math.floor((Date.now() - startedAt) / 1000);
        setSeconds(s);
        if (s >= 120) stop(); // máximo 2 minutos
      }, 500);
    } catch {
      setError('Não consegui acessar o microfone. Libere a permissão do microfone para este site.');
    }
  };

  const stop = () => {
    window.clearInterval(timer.current);
    if (recRef.current && recRef.current.state !== 'inactive') recRef.current.stop();
    setRecording(false);
  };

  const mmss = `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-3">
      <div className="bg-[#1c1c1c] border border-[#8A8D91]/30 rounded-2xl w-full max-w-md p-5 space-y-4 shadow-2xl relative">
        <button onClick={onClose} className="absolute top-3 right-3 p-2 text-[#8A8D91] hover:text-[#F4F4F2]">
          <X className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#C8102E]/20 text-[#C8102E] flex items-center justify-center border border-[#C8102E]/30">
            <Mic className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-sora font-bold">Gravar vinheta de voz</h3>
            <p className="text-xs text-[#8A8D91]">Fica salva na nuvem e entra na cartucheira</p>
          </div>
        </div>

        {error && (
          <div className="bg-[#C8102E]/15 border border-[#C8102E]/40 text-[#F4F4F2] text-xs p-3 rounded-xl flex gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-[#C8102E]" />
            {error}
          </div>
        )}

        <div className="flex flex-col items-center gap-3 py-5 bg-[#141414] rounded-xl border border-[#8A8D91]/20">
          <div className={`font-sora text-3xl font-extrabold ${recording ? 'text-[#C8102E]' : ''}`}>{mmss}</div>
          {!recording ? (
            <button
              onClick={start}
              className="px-5 py-3 rounded-full bg-[#C8102E] hover:bg-[#b00d27] font-sora font-semibold text-sm flex items-center gap-2"
            >
              {blob ? <RotateCcw className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              {blob ? 'Gravar de novo' : 'Começar a gravar'}
            </button>
          ) : (
            <button
              onClick={stop}
              className="px-5 py-3 rounded-full bg-[#F4F4F2] text-[#141414] font-sora font-semibold text-sm flex items-center gap-2 animate-pulse"
            >
              <Square className="w-4 h-4 fill-current" /> Parar gravação
            </button>
          )}
          {previewUrl && <audio src={previewUrl} controls className="w-full px-3" />}
        </div>

        {blob && (
          <div className="space-y-3">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3.5 py-3 rounded-xl bg-[#141414] border border-[#8A8D91]/30 focus:border-[#C8102E] focus:outline-none text-sm"
              placeholder="Nome da vinheta"
            />
            <button
              onClick={() => onSave(blob, name.trim() || 'Aviso gravado')}
              className="w-full py-3 rounded-xl bg-[#C8102E] hover:bg-[#b00d27] font-sora font-semibold text-sm flex items-center justify-center gap-2"
            >
              <Check className="w-4 h-4" /> Salvar na cartucheira
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
