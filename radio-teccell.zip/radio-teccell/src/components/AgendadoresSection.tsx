import { useState } from 'react';
import { Clock, Play, Pause, SkipForward, CheckCircle2, ChevronUp, ChevronDown } from 'lucide-react';
import type { RadioState } from '../../shared/state.ts';
import { rotationOf } from '../../shared/state.ts';
import type { Act } from '../control/ControlApp.tsx';

interface Props {
  state: RadioState;
  act: Act;
  serverNow: number;
}

const PRESETS = [3, 5, 10, 15, 30, 60];

const fmt = (ms: number) => {
  const sec = Math.max(0, Math.ceil(ms / 1000));
  return `${String(Math.floor(sec / 60)).padStart(2, '0')}:${String(sec % 60).padStart(2, '0')}`;
};

export const AgendadoresSection = ({ state, act, serverNow }: Props) => {
  const { scheduler } = state;
  const rotation = rotationOf(state);
  const nextIdx = rotation.length ? scheduler.nextIndex % rotation.length : 0;
  const next = rotation[nextIdx];
  const [custom, setCustom] = useState('');

  return (
    <section className="bg-[#1c1c1c] rounded-2xl p-4 sm:p-5 border border-[#8A8D91]/20 shadow-xl space-y-4">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h2 className="font-sora text-base sm:text-lg font-bold flex items-center gap-2 tracking-tight">
            <span className="w-2.5 h-2.5 rounded-full bg-[#C8102E]" />
            Agendador
          </h2>
          <p className="text-xs text-[#8A8D91] mt-0.5">1 vinheta a cada {scheduler.intervalMinutes} min, na ordem</p>
        </div>
        <button
          onClick={() => act({ type: 'schedulerToggle', active: !scheduler.active })}
          disabled={rotation.length === 0}
          className={`px-4 py-2.5 rounded-xl font-sora font-semibold text-xs flex items-center gap-1.5 disabled:opacity-40 ${
            !scheduler.active ? 'bg-[#C8102E] hover:bg-[#b00d27]' : 'bg-[#242424] border border-[#8A8D91]/30'
          }`}
        >
          {scheduler.active ? (
            <>
              <Pause className="w-3.5 h-3.5 fill-current text-[#C8102E]" /> Pausar
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5 fill-current" /> Ligar
            </>
          )}
        </button>
      </div>

      <div className="p-4 rounded-xl bg-[#141414] border border-[#8A8D91]/25 space-y-3">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <span className="text-[11px] font-semibold text-[#8A8D91] uppercase tracking-wider block">Próxima:</span>
            <div className="text-sm font-bold truncate">
              {next ? (
                <>
                  <span className="text-[#C8102E] font-mono text-xs mr-1.5">#{nextIdx + 1}</span>
                  {next.name}
                </>
              ) : (
                <span className="text-[#8A8D91] font-normal italic text-xs">Nenhuma vinheta na rotação</span>
              )}
            </div>
          </div>
          <div className="text-right shrink-0">
            <span className="text-[10px] text-[#8A8D91] uppercase tracking-wider block font-semibold">
              {scheduler.active ? 'Falta' : 'Status'}
            </span>
            <div className={`font-sora text-2xl font-extrabold ${scheduler.active ? '' : 'text-[#8A8D91]'}`}>
              {scheduler.active && scheduler.nextRunAt ? fmt(scheduler.nextRunAt - serverNow) : 'PAUSADO'}
            </div>
          </div>
        </div>
        <div className="pt-2 border-t border-[#8A8D91]/15 flex items-center justify-between gap-2">
          <span className="text-[11px] text-[#8A8D91]">
            {rotation.length ? `${nextIdx + 1} de ${rotation.length}` : '0 de 0'}
          </span>
          <button
            onClick={() => act({ type: 'schedulerPlayNext' })}
            disabled={rotation.length === 0}
            className="px-3 py-2 bg-[#242424] border border-[#8A8D91]/30 rounded-lg text-xs font-semibold flex items-center gap-1.5 disabled:opacity-40"
          >
            <SkipForward className="w-3.5 h-3.5 text-[#C8102E]" /> Tocar próxima agora
          </button>
        </div>
      </div>

      <div className="space-y-2">
        <div className="text-xs font-semibold flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 text-[#8A8D91]" /> Intervalo
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          {PRESETS.map((m) => (
            <button
              key={m}
              onClick={() => act({ type: 'schedulerInterval', minutes: m })}
              className={`px-3 py-2 rounded-lg text-xs font-sora font-semibold border ${
                scheduler.intervalMinutes === m
                  ? 'bg-[#141414] border-[#C8102E] ring-1 ring-[#C8102E]/30'
                  : 'bg-[#141414] text-[#8A8D91] border-[#8A8D91]/25'
              }`}
            >
              {m} min
            </button>
          ))}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              const n = parseInt(custom, 10);
              if (n > 0) void act({ type: 'schedulerInterval', minutes: n }).then((ok) => ok && setCustom(''));
            }}
            className="flex items-center gap-1"
          >
            <input
              value={custom}
              onChange={(e) => setCustom(e.target.value.replace(/\D/g, ''))}
              inputMode="numeric"
              placeholder="outro"
              className="w-16 px-2 py-2 rounded-lg bg-[#141414] border border-[#8A8D91]/25 text-xs focus:outline-none focus:border-[#C8102E]"
            />
            {custom && <button className="px-2.5 py-2 rounded-lg bg-[#242424] text-xs border border-[#8A8D91]/25">OK</button>}
          </form>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-[#8A8D91] font-semibold">
          <span>Ordem da rotação ({rotation.length})</span>
          <span className="text-[11px] font-normal">toque para escolher a próxima</span>
        </div>
        <div className="max-h-[320px] overflow-y-auto pr-1 space-y-2">
          {rotation.length === 0 ? (
            <div className="text-center py-8 px-4 bg-[#141414] rounded-xl border border-[#8A8D91]/20 text-[#8A8D91] text-xs">
              Marque vinhetas como “Na rotação” na cartucheira.
            </div>
          ) : (
            rotation.map((item, i) => {
              const isNext = i === nextIdx;
              return (
                <div
                  key={item.id}
                  onClick={() => act({ type: 'schedulerSetNext', index: i })}
                  className={`p-2.5 rounded-xl border cursor-pointer flex items-center justify-between gap-2 bg-[#141414] ${
                    isNext ? 'border-[#C8102E]/70' : 'border-[#8A8D91]/20'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span
                      className={`w-6 h-6 rounded-lg text-xs font-bold flex items-center justify-center font-mono shrink-0 ${
                        isNext ? 'bg-[#C8102E]' : 'bg-[#242424] text-[#8A8D91]'
                      }`}
                    >
                      {i + 1}
                    </span>
                    <div className="min-w-0">
                      <div className="text-xs font-semibold truncate">{item.name}</div>
                      {isNext && (
                        <div className="text-[10px] flex items-center gap-1 mt-0.5">
                          <CheckCircle2 className="w-3 h-3 text-[#C8102E]" /> Próxima a tocar
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                    <button
                      disabled={i === 0}
                      onClick={() => act({ type: 'jingleMove', id: item.id, dir: -1 })}
                      className="p-1.5 rounded-lg bg-[#242424] border border-[#8A8D91]/20 disabled:opacity-30"
                      title="Subir"
                    >
                      <ChevronUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      disabled={i === rotation.length - 1}
                      onClick={() => act({ type: 'jingleMove', id: item.id, dir: 1 })}
                      className="p-1.5 rounded-lg bg-[#242424] border border-[#8A8D91]/20 disabled:opacity-30"
                      title="Descer"
                    >
                      <ChevronDown className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </section>
  );
};
