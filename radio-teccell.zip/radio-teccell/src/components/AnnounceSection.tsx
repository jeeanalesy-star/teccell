import { useState } from 'react';
import { Megaphone, Mic, Send, Square } from 'lucide-react';
import type { Act } from '../control/ControlApp.tsx';
import { MicrophoneRecorder } from './MicrophoneRecorder.tsx';

interface Props {
  act: Act;
  onUploadRecording: (blob: Blob, name: string) => Promise<void>;
}

const QUICK = [
  'Atenção, cliente! Seu aparelho já está pronto para retirada no balcão.',
  'Aproveite: iPhones com garantia de até 6 meses só aqui na TecCell!',
  'Celulares Android parcelados no boleto. Fale com um de nossos atendentes!',
];

export const AnnounceSection = ({ act, onUploadRecording }: Props) => {
  const [text, setText] = useState('');
  const [recording, setRecording] = useState(false);

  const send = async (t: string) => {
    if (!t.trim()) return;
    if (await act({ type: 'tts', text: t.trim() })) setText('');
  };

  return (
    <section className="bg-[#1c1c1c] rounded-2xl p-4 sm:p-5 border border-[#8A8D91]/20 shadow-xl space-y-3">
      <div className="flex items-center justify-between gap-2">
        <h2 className="font-sora text-base sm:text-lg font-bold flex items-center gap-2 tracking-tight">
          <Megaphone className="w-4 h-4 text-[#C8102E]" />
          Aviso na hora
        </h2>
        <button
          onClick={() => act({ type: 'stopJingles' })}
          className="text-xs px-3 py-1.5 rounded-lg bg-[#242424] border border-[#8A8D91]/30 flex items-center gap-1.5"
          title="Interrompe a vinheta ou aviso que estiver tocando"
        >
          <Square className="w-3 h-3 fill-current text-[#C8102E]" /> Parar vinheta
        </button>
      </div>

      <div className="flex gap-2">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && send(text)}
          placeholder="Digite um aviso para o notebook falar…"
          maxLength={400}
          className="flex-1 min-w-0 px-3.5 py-3 rounded-xl bg-[#141414] border border-[#8A8D91]/30 focus:border-[#C8102E] focus:outline-none text-sm placeholder:text-[#8A8D91]/60"
        />
        <button
          onClick={() => send(text)}
          disabled={!text.trim()}
          className="px-4 py-3 bg-[#C8102E] hover:bg-[#b00d27] rounded-xl font-sora font-semibold text-sm flex items-center gap-1.5 disabled:opacity-40"
        >
          <Send className="w-4 h-4" /> Falar
        </button>
      </div>

      <div className="flex flex-wrap gap-2">
        {QUICK.map((q) => (
          <button
            key={q}
            onClick={() => send(q)}
            className="text-left text-[11px] px-3 py-2 rounded-lg bg-[#141414] border border-[#8A8D91]/25 text-[#8A8D91] hover:text-[#F4F4F2] hover:border-[#8A8D91]/50"
          >
            {q}
          </button>
        ))}
      </div>

      <button
        onClick={() => setRecording(true)}
        className="w-full py-3 rounded-xl border-2 border-dashed border-[#8A8D91]/30 hover:border-[#C8102E]/70 text-sm font-semibold flex items-center justify-center gap-2"
      >
        <Mic className="w-4 h-4 text-[#C8102E]" /> Gravar vinheta com a minha voz
      </button>

      {recording && (
        <MicrophoneRecorder
          onClose={() => setRecording(false)}
          onSave={async (blob, name) => {
            setRecording(false);
            await onUploadRecording(blob, name);
          }}
        />
      )}
    </section>
  );
};
