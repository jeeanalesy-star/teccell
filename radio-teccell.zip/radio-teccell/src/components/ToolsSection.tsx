import { useState } from 'react';
import { Settings, RefreshCw, LogOut, CloudDownload, ExternalLink } from 'lucide-react';
import type { Act } from '../control/ControlApp.tsx';

interface Props {
  act: Act;
  upload: (files: { blob: Blob; name: string }[]) => Promise<void>;
  onLogout: () => void;
  showToast: (t: string, error?: boolean) => void;
}

export const ToolsSection = ({ act, upload, onLogout, showToast }: Props) => {
  const [open, setOpen] = useState(false);
  const [migrating, setMigrating] = useState<string | null>(null);

  const migrate = async () => {
    if (!confirm('Copiar rádios favoritas e vinhetas do sistema antigo (Firebase) para a nuvem do Netlify?')) return;
    try {
      const { migrateFromFirebase } = await import('../lib/migrate.ts');
      const r = await migrateFromFirebase({ act, upload, progress: setMigrating });
      showToast(`Importado: ${r.favs} rádio(s) e ${r.vinhetas} vinheta(s).`);
    } catch (err) {
      showToast(`Não foi possível ler o sistema antigo: ${(err as Error).message}`, true);
    }
    setMigrating(null);
  };

  return (
    <section className="bg-[#1c1c1c] rounded-2xl border border-[#8A8D91]/20">
      <button onClick={() => setOpen(!open)} className="w-full p-4 flex items-center gap-2 text-sm font-semibold text-[#8A8D91]">
        <Settings className="w-4 h-4" /> Ferramentas
        <span className="ml-auto text-xs">{open ? 'fechar' : 'abrir'}</span>
      </button>
      {open && (
        <div className="px-4 pb-4 grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
          <button
            onClick={() => act({ type: 'reloadPlayer' })}
            className="p-3 rounded-xl bg-[#141414] border border-[#8A8D91]/25 flex items-center gap-2 text-left"
          >
            <RefreshCw className="w-4 h-4 text-[#C8102E] shrink-0" />
            <span>
              Recarregar o notebook
              <span className="block text-[11px] text-[#8A8D91]">Use se ele travar. Pode pedir um novo clique para o som.</span>
            </span>
          </button>
          <button
            onClick={migrate}
            disabled={!!migrating}
            className="p-3 rounded-xl bg-[#141414] border border-[#8A8D91]/25 flex items-center gap-2 text-left disabled:opacity-60"
          >
            <CloudDownload className="w-4 h-4 text-[#C8102E] shrink-0" />
            <span className="min-w-0">
              Importar do sistema antigo
              <span className="block text-[11px] text-[#8A8D91] truncate">{migrating || 'Traz rádios e vinhetas do Firebase'}</span>
            </span>
          </button>
          <a
            href="/player"
            target="_blank"
            rel="noreferrer"
            className="p-3 rounded-xl bg-[#141414] border border-[#8A8D91]/25 flex items-center gap-2"
          >
            <ExternalLink className="w-4 h-4 text-[#C8102E] shrink-0" />
            <span>
              Abrir o player
              <span className="block text-[11px] text-[#8A8D91]">Endereço para abrir no notebook: /player</span>
            </span>
          </a>
          <button onClick={onLogout} className="p-3 rounded-xl bg-[#141414] border border-[#8A8D91]/25 flex items-center gap-2 text-left">
            <LogOut className="w-4 h-4 text-[#8A8D91] shrink-0" /> Sair (esquecer PIN neste celular)
          </button>
        </div>
      )}
    </section>
  );
};
