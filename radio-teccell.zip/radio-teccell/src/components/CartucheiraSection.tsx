import { useRef, useState } from 'react';
import { Upload, Trash2, Music, Edit2, Play, Repeat, Sparkles, LoaderCircle } from 'lucide-react';
import type { RadioState, SynthType } from '../../shared/state.ts';
import type { Act } from '../control/ControlApp.tsx';
import { VolumeSlider } from './VolumeSlider.tsx';

interface Props {
  state: RadioState;
  act: Act;
  onUpload: (files: { blob: Blob; name: string }[]) => Promise<void>;
  uploading: string | null;
}

const SYNTHS: { type: SynthType; name: string }[] = [
  { type: 'promo', name: 'Vinheta Oficial TecCell' },
  { type: 'sale', name: 'Super Oferta de Celulares' },
  { type: 'announcement', name: 'Aviso aos Clientes' },
];

const kb = (n?: number) => (n ? `${Math.max(1, Math.round(n / 1024))} KB` : '');

export const CartucheiraSection = ({ state, act, onUpload, uploading }: Props) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const { jingles, volumes } = state;

  const handleFiles = (list: FileList | null) => {
    if (!list || !list.length) return;
    const files = Array.from(list).map((f) => ({ blob: f as Blob, name: f.name.replace(/\.[^/.]+$/, '') }));
    void onUpload(files);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const missingSynths = SYNTHS.filter((s) => !jingles.some((j) => j.kind === 'synth' && j.synthType === s.type));

  return (
    <section className="bg-[#1c1c1c] rounded-2xl p-4 sm:p-5 border border-[#8A8D91]/20 shadow-xl space-y-4">
      <div className="flex items-center justify-between gap-2">
        <h2 className="font-sora text-base sm:text-lg font-bold flex items-center gap-2 tracking-tight">
          <span className="w-2.5 h-2.5 rounded-full bg-[#C8102E]" />
          Cartucheira de vinhetas
        </h2>
        <div className="flex items-center gap-2">
          {jingles.length > 0 && (
            <button
              onClick={() => confirm('Apagar TODAS as vinhetas da nuvem?') && act({ type: 'jingleClear' })}
              className="text-xs text-[#8A8D91] hover:text-[#C8102E] bg-[#141414] border border-[#8A8D91]/20 px-2.5 py-1 rounded-full flex items-center gap-1"
            >
              <Trash2 className="w-3 h-3" /> Zerar
            </button>
          )}
          <span className="text-xs text-[#8A8D91] font-mono bg-[#141414] px-2.5 py-1 rounded-full border border-[#8A8D91]/30">
            {jingles.length}
          </span>
        </div>
      </div>

      <div
        onClick={() => !uploading && fileInputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          handleFiles(e.dataTransfer.files);
        }}
        className={`w-full border-2 border-dashed p-4 rounded-xl cursor-pointer flex items-center justify-center gap-3.5 ${
          dragOver ? 'border-[#C8102E] bg-[#C8102E]/10' : 'border-[#8A8D91]/30 bg-[#141414] hover:border-[#C8102E]/80'
        }`}
      >
        <div className="p-2.5 rounded-xl bg-[#242424] border border-[#8A8D91]/20">
          {uploading ? <LoaderCircle className="w-5 h-5 animate-spin text-[#C8102E]" /> : <Upload className="w-5 h-5" />}
        </div>
        <div className="text-left min-w-0">
          <span className="text-sm font-semibold block truncate">{uploading || 'Adicionar vinhetas de áudio'}</span>
          <span className="text-xs text-[#8A8D91] block">MP3, M4A ou WAV até 5 MB • ficam salvas na nuvem</span>
        </div>
        <input
          type="file"
          ref={fileInputRef}
          onChange={(e) => handleFiles(e.target.files)}
          accept="audio/*"
          multiple
          className="hidden"
        />
      </div>

      <div className="pt-1 border-t border-[#8A8D91]/20">
        <VolumeSlider label="Volume vinhetas" value={volumes.jingle} onCommit={(v) => act({ type: 'volume', jingle: v })} />
      </div>

      {jingles.length === 0 ? (
        <div className="min-h-[140px] flex flex-col items-center justify-center border border-dashed border-[#8A8D91]/20 rounded-xl p-6 text-center text-[#8A8D91] space-y-2">
          <Music className="w-7 h-7 text-[#8A8D91]/60" />
          <p className="text-xs font-semibold text-[#F4F4F2]">Nenhuma vinheta cadastrada.</p>
          <p className="text-[11px]">Envie um áudio acima ou grave com a sua voz.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {jingles.map((item, index) => (
            <div key={item.id} className="p-3 rounded-xl border bg-[#141414] border-[#8A8D91]/25 flex flex-col justify-between gap-2.5">
              <div className="flex items-start gap-2">
                <span className="font-mono text-[11px] font-bold text-[#8A8D91] px-1.5 py-0.5 rounded bg-[#242424]">#{index + 1}</span>
                <div className="min-w-0">
                  <div className="text-xs font-semibold leading-snug break-words">{item.name}</div>
                  <div className="text-[10px] text-[#8A8D91] mt-0.5 flex items-center gap-1">
                    {item.kind === 'synth' ? (
                      <>
                        <Sparkles className="w-3 h-3" /> Voz automática
                      </>
                    ) : (
                      <>Áudio • {kb(item.size)}</>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-[#8A8D91]/15 gap-1.5">
                <button
                  onClick={() => act({ type: 'jinglePlay', id: item.id })}
                  className="px-3 py-2 bg-[#C8102E] hover:bg-[#b00d27] rounded-lg text-xs font-semibold flex items-center gap-1.5"
                >
                  <Play className="w-3 h-3 fill-current" /> Tocar
                </button>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => act({ type: 'jingleRotation', id: item.id, inRotation: !item.inRotation })}
                    className={`px-2 py-2 rounded-lg border text-[11px] font-medium flex items-center gap-1 ${
                      item.inRotation
                        ? 'bg-[#C8102E]/15 border-[#C8102E]/50 text-[#F4F4F2]'
                        : 'bg-[#242424] border-[#8A8D91]/20 text-[#8A8D91]'
                    }`}
                    title="Incluir ou tirar do agendador automático"
                  >
                    <Repeat className="w-3 h-3" /> {item.inRotation ? 'Na rotação' : 'Fora'}
                  </button>
                  <button
                    onClick={() => {
                      const n = prompt('Novo nome da vinheta:', item.name);
                      if (n && n.trim()) void act({ type: 'jingleRename', id: item.id, name: n.trim() });
                    }}
                    className="p-2 bg-[#242424] text-[#8A8D91] hover:text-[#F4F4F2] rounded-lg border border-[#8A8D91]/20"
                    title="Renomear"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => confirm(`Excluir "${item.name}"?`) && act({ type: 'jingleDel', id: item.id })}
                    className="p-2 bg-[#242424] hover:bg-[#C8102E]/20 text-[#8A8D91] hover:text-[#C8102E] rounded-lg border border-[#8A8D91]/20"
                    title="Excluir"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {missingSynths.length > 0 && (
        <div className="flex flex-wrap items-center gap-2 text-[11px] text-[#8A8D91]">
          <span>Adicionar vinheta de voz automática:</span>
          {missingSynths.map((s) => (
            <button
              key={s.type}
              onClick={() => act({ type: 'jingleAddSynth', name: s.name, synthType: s.type })}
              className="px-2.5 py-1.5 rounded-lg bg-[#141414] border border-[#8A8D91]/25 hover:text-[#F4F4F2]"
            >
              + {s.name}
            </button>
          ))}
        </div>
      )}
    </section>
  );
};
