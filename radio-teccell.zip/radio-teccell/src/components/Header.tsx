import { Radio, Signal, Volume2, Laptop, WifiOff } from 'lucide-react';
import type { PlayerHeartbeat } from '../../shared/state.ts';

interface HeaderProps {
  player: PlayerHeartbeat | null;
  online: boolean;
  serverNow: number;
}

const LABEL: Record<string, string> = {
  locked: 'NOTEBOOK SEM ÁUDIO',
  idle: 'RÁDIO PARADA',
  connecting: 'CONECTANDO…',
  radio: 'NO AR',
  jingle: 'VINHETA NO AR',
  error: 'RECONECTANDO',
};

export const Header = ({ player, online, serverNow }: HeaderProps) => {
  const playerOnline = !!player && serverNow - player.lastSeen < 45_000;
  const status = playerOnline ? player!.status : 'offline';

  const badge =
    status === 'radio'
      ? 'bg-[#C8102E] text-[#F4F4F2] shadow-lg shadow-[#C8102E]/25 border-[#C8102E]'
      : status === 'jingle'
        ? 'bg-[#F4F4F2] text-[#141414] border-[#F4F4F2]'
        : status === 'error' || status === 'locked'
          ? 'bg-[#C8102E]/20 text-[#C8102E] border-[#C8102E]/40'
          : 'bg-[#141414] text-[#8A8D91] border-[#8A8D91]/30';

  return (
    <header className="relative overflow-hidden bg-[#1c1c1c] p-4 sm:p-5 rounded-2xl border border-[#8A8D91]/20 shadow-2xl space-y-3">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-6 -bottom-10 w-44 h-44 rounded-full border-[18px] border-[#C8102E]/10 border-r-transparent rotate-[-25deg]"
      />
      <div className="flex items-center justify-between gap-3 relative z-10">
        <div className="flex items-center gap-3">
          <div className="h-12 px-3 bg-[#141414] rounded-xl border border-[#8A8D91]/30 flex items-center font-sora font-black tracking-tighter text-xl">
            <span>t</span>
            <span className="text-[#C8102E]">c</span>
          </div>
          <div>
            <h1 className="font-sora text-lg sm:text-2xl font-bold tracking-tight">
              Tec<span className="text-[#C8102E]">C</span>ell
              <span className="text-[13px] font-normal text-[#8A8D91] ml-2 font-inter">Rádio Indoor</span>
            </h1>
            <div className="text-xs text-[#8A8D91] italic">Controle remoto</div>
          </div>
        </div>
        <div
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[11px] font-semibold ${
            online ? 'border-emerald-500/30 text-emerald-400' : 'border-[#C8102E]/40 text-[#C8102E]'
          }`}
        >
          {online ? <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" /> : <WifiOff className="w-3.5 h-3.5" />}
          {online ? 'Nuvem' : 'Offline'}
        </div>
      </div>

      <div className="relative z-10 flex items-center gap-2.5 p-3 rounded-xl bg-[#141414] border border-[#8A8D91]/20">
        <Laptop className={`w-5 h-5 shrink-0 ${playerOnline ? 'text-emerald-400' : 'text-[#8A8D91]'}`} />
        <div className="min-w-0 flex-1">
          <div className="text-[11px] text-[#8A8D91] font-semibold uppercase tracking-wider">Notebook da rádio</div>
          <div className="text-xs truncate">
            {playerOnline
              ? player!.detail
              : player
                ? 'Desligado ou sem internet (abra o /player no notebook)'
                : 'Ainda não conectado — abra o endereço /player no notebook'}
          </div>
        </div>
        <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border font-sora tracking-wider flex items-center gap-1 shrink-0 ${badge}`}>
          {status === 'radio' && <Signal className="w-3 h-3" />}
          {status === 'jingle' && <Volume2 className="w-3 h-3" />}
          {(status === 'offline' || status === 'idle') && <Radio className="w-3 h-3" />}
          {playerOnline ? LABEL[status] || status : 'OFFLINE'}
        </span>
      </div>
    </header>
  );
};
