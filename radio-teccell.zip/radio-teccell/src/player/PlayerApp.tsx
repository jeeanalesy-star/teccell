import { useEffect, useState } from 'react';
import { Radio, Volume2, Wifi, WifiOff, Clock, Power, ListMusic, Smartphone } from 'lucide-react';
import { RadioEngine } from './engine.ts';
import { rotationOf } from '../../shared/state.ts';

const engine = new RadioEngine();

const fmt = (ms: number) => {
  const sec = Math.max(0, Math.ceil(ms / 1000));
  const m = Math.floor(sec / 60);
  return `${String(m).padStart(2, '0')}:${String(sec % 60).padStart(2, '0')}`;
};

const STATUS_LABEL: Record<string, string> = {
  locked: 'ÁUDIO BLOQUEADO',
  idle: 'RÁDIO PARADA',
  connecting: 'CONECTANDO…',
  radio: 'NO AR',
  jingle: 'VINHETA NO AR',
  error: 'RECONECTANDO',
};

export default function PlayerApp() {
  const [snap, setSnap] = useState(() => engine.snapshot());
  useEffect(() => {
    const off = engine.subscribe(() => setSnap(engine.snapshot()));
    engine.start();
    return () => {
      off();
    };
  }, []);
  const s = snap.state;

  const rotation = s ? rotationOf(s) : [];
  const nextJingle = s && rotation.length ? rotation[s.scheduler.nextIndex % rotation.length] : null;
  const remaining = s?.scheduler.active && s.scheduler.nextRunAt ? s.scheduler.nextRunAt - snap.serverNow : null;

  const badge =
    snap.status === 'radio'
      ? 'bg-[#C8102E] text-[#F4F4F2] border-[#C8102E]'
      : snap.status === 'jingle'
        ? 'bg-[#F4F4F2] text-[#141414] border-[#F4F4F2]'
        : snap.status === 'error'
          ? 'bg-[#C8102E]/20 text-[#C8102E] border-[#C8102E]/40'
          : 'bg-[#242424] text-[#8A8D91] border-[#8A8D91]/30';

  return (
    <div className="min-h-screen bg-[#141414] text-[#F4F4F2] p-4 sm:p-8 flex justify-center">
      {!snap.unlocked && (
        <button
          onClick={() => engine.unlock()}
          className="fixed inset-0 z-50 bg-[#141414]/95 flex flex-col items-center justify-center gap-6 text-center p-8 cursor-pointer"
        >
          <div className="w-28 h-28 rounded-full bg-[#C8102E] flex items-center justify-center shadow-2xl shadow-[#C8102E]/40 animate-pulse">
            <Power className="w-14 h-14 text-[#F4F4F2]" />
          </div>
          <div className="space-y-2">
            <div className="font-sora text-3xl font-extrabold">Clique para ligar a Rádio TecCell</div>
            <div className="text-[#8A8D91] max-w-lg mx-auto">
              O navegador só libera o som depois de um clique. Depois disso, este notebook obedece aos comandos do
              celular sozinho — deixe esta aba aberta.
            </div>
          </div>
        </button>
      )}

      <div className="w-full max-w-[1100px] flex flex-col gap-5">
        <header className="bg-[#1c1c1c] p-5 rounded-2xl border border-[#8A8D91]/20 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="h-14 px-3.5 bg-[#141414] rounded-xl border border-[#8A8D91]/30 flex items-center font-sora font-black text-2xl tracking-tighter">
              <span>t</span>
              <span className="text-[#C8102E]">c</span>
            </div>
            <div>
              <h1 className="font-sora text-2xl font-bold">
                Tec<span className="text-[#C8102E]">C</span>ell <span className="text-[#8A8D91] text-base font-normal font-inter">Rádio Indoor • Player</span>
              </h1>
              <div className="text-xs text-[#8A8D91] italic">Sua tecnologia em boas mãos.</div>
            </div>
          </div>
          <div
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs font-semibold ${
              snap.online ? 'border-emerald-500/40 text-emerald-400' : 'border-[#C8102E]/50 text-[#C8102E]'
            }`}
          >
            {snap.online ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
            {snap.online ? 'Conectado à nuvem' : 'Sem conexão — tentando…'}
          </div>
        </header>

        <section className="relative overflow-hidden bg-[#1c1c1c] rounded-2xl p-6 sm:p-8 border border-[#8A8D91]/20 space-y-5">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -right-10 -bottom-16 w-64 h-64 rounded-full border-[26px] border-[#C8102E]/10 border-r-transparent rotate-[-25deg]"
          />
          <div className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full border font-sora font-bold text-sm tracking-wider ${badge}`}>
            {snap.status === 'jingle' ? <Volume2 className="w-4 h-4" /> : <Radio className="w-4 h-4" />}
            {STATUS_LABEL[snap.status] || snap.status}
          </div>
          <div className="font-sora text-3xl sm:text-5xl font-extrabold leading-tight break-words">
            {snap.nowJingle || s?.stream.name || (s?.stream.url ? 'Rádio online' : 'Nenhuma rádio selecionada')}
          </div>
          <div className="text-[#8A8D91] text-sm sm:text-base break-all">{snap.detail}</div>
          {snap.nowJingle && s?.stream.playing && (
            <div className="text-sm text-[#8A8D91]">
              Rádio em segundo plano a {Math.round((s.volumes.duck ?? 0.2) * 100)}% durante a vinheta
            </div>
          )}
          <div className="flex flex-wrap gap-3 pt-2 text-xs">
            <span className="px-3 py-1.5 rounded-lg bg-[#141414] border border-[#8A8D91]/25">
              Volume rádio: <b>{Math.round((s?.volumes.stream ?? 0) * 100)}%</b>
            </span>
            <span className="px-3 py-1.5 rounded-lg bg-[#141414] border border-[#8A8D91]/25">
              Volume vinhetas: <b>{Math.round((s?.volumes.jingle ?? 0) * 100)}%</b>
            </span>
            {snap.queueSize > 0 && (
              <span className="px-3 py-1.5 rounded-lg bg-[#141414] border border-[#C8102E]/40">
                Na fila: <b>{snap.queueSize}</b>
              </span>
            )}
          </div>
        </section>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <section className="bg-[#1c1c1c] rounded-2xl p-5 border border-[#8A8D91]/20 space-y-3">
            <h2 className="font-sora font-bold flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#C8102E]" /> Agendador de vinhetas
            </h2>
            {s?.scheduler.active ? (
              <>
                <div className="font-sora text-5xl font-extrabold">{remaining !== null ? fmt(remaining) : '--:--'}</div>
                <div className="text-sm text-[#8A8D91]">
                  Próxima: <span className="text-[#F4F4F2] font-semibold">{nextJingle?.name || '—'}</span> • a cada{' '}
                  {s.scheduler.intervalMinutes} min
                </div>
              </>
            ) : (
              <div className="font-sora text-2xl font-bold text-[#8A8D91]">PAUSADO</div>
            )}
            <div className="text-xs text-[#8A8D91] flex items-center gap-1.5">
              <ListMusic className="w-3.5 h-3.5" /> {rotation.length} na rotação • {snap.cached} áudio(s) salvos neste notebook
            </div>
          </section>

          <section className="bg-[#1c1c1c] rounded-2xl p-5 border border-[#8A8D91]/20 space-y-3">
            <h2 className="font-sora font-bold">Últimos acontecimentos</h2>
            <ul className="space-y-1.5 text-sm max-h-48 overflow-y-auto pr-1">
              {snap.log.map((l, i) => (
                <li key={`${l.at}-${i}`} className="flex gap-3">
                  <span className="font-mono text-[#8A8D91] text-xs pt-0.5 shrink-0">
                    {new Date(l.at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </span>
                  <span>{l.text}</span>
                </li>
              ))}
            </ul>
          </section>
        </div>

        <footer className="text-xs text-[#8A8D91] flex flex-wrap items-center justify-between gap-2 pb-4">
          <span className="flex items-center gap-1.5">
            <Smartphone className="w-3.5 h-3.5" /> Controle pelo celular em{' '}
            <b className="text-[#F4F4F2]">{window.location.host}</b>
          </span>
          <span>Mantenha esta aba aberta e o notebook ligado na tomada.</span>
        </footer>
      </div>
    </div>
  );
}
