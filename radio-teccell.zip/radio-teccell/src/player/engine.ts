// Motor de áudio do notebook: obedece ao estado salvo no Netlify.
// - Toca/para a rádio e reconecta sozinho se o stream cair
// - Executa os comandos (vinheta, aviso falado, parar vinheta) assim que chegam
// - Abaixa a rádio durante as vinhetas (ducking) e volta depois
// - Dispara o agendador de vinhetas no horário certo
import { RadioSync, sendAction } from '../lib/api.ts';
import { cacheDel, cacheKeys, getAudio } from '../lib/audioCache.ts';
import { audioContext, playChimeAndSpeak, synthText } from '../lib/synth.ts';
import type { Command, Jingle, PlayerStatusKind, RadioState } from '../../shared/state.ts';
import { rotationOf } from '../../shared/state.ts';

type QueueItem = { kind: 'jingle'; jingle: Jingle; source: string } | { kind: 'tts'; text: string };

export interface LogEntry {
  at: number;
  text: string;
}

export interface EngineSnapshot {
  state: RadioState | null;
  unlocked: boolean;
  online: boolean;
  status: PlayerStatusKind;
  detail: string;
  nowJingle: string | null;
  queueSize: number;
  log: LogEntry[];
  cached: number;
  serverNow: number;
}

const SEQ_KEY = 'teccell-player-last-seq';
const MAX_CMD_AGE = 2 * 60_000;

export class RadioEngine {
  private state: RadioState | null = null;
  private radio = new Audio();
  private unlocked = false;
  private online = false;
  private lastSeq: number | null = null;
  private queue: QueueItem[] = [];
  private current: { label: string; stop: () => void; audio?: HTMLAudioElement } | null = null;
  private currentUrl = '';
  private retryTimer: number | undefined;
  private retryDelay = 2000;
  private streamError: string | null = null;
  private status: PlayerStatusKind = 'locked';
  private detail = 'Clique para ativar o áudio';
  private log: LogEntry[] = [];
  private cached = 0;
  private lastFire: { runAt: number; at: number } | null = null;
  private lastProgress = { time: 0, at: 0 };
  private fadeTimer: number | undefined;
  private wakeLock: { release: () => Promise<void> } | null = null;
  private listeners = new Set<() => void>();
  private hbTimer: number | undefined;
  readonly sync: RadioSync;

  constructor() {
    this.radio.preload = 'none';
    this.radio.addEventListener('playing', () => {
      this.retryDelay = 2000;
      if (this.streamError) this.addLog('Rádio reconectada');
      this.streamError = null;
      this.refreshStatus();
    });
    this.radio.addEventListener('waiting', () => this.refreshStatus());
    this.radio.addEventListener('error', () => this.onStreamFailure('erro no stream'));
    this.radio.addEventListener('ended', () => this.onStreamFailure('stream terminou'));

    this.sync = new RadioSync({
      onState: (s) => this.onState(s),
      onConnection: (ok) => {
        this.online = ok;
        this.emit();
      },
      heartbeat: () => ({ status: this.status, detail: this.detail }),
    });
  }

  // ---------- ciclo de vida ----------

  private started = false;

  start() {
    if (this.started) return;
    this.started = true;
    try {
      const saved = localStorage.getItem(SEQ_KEY);
      if (saved !== null) this.lastSeq = Number(saved);
    } catch {
      /* ignore */
    }
    // Se o navegador já permite som sem clique (ex.: Chrome com --autoplay-policy), libera direto.
    this.addLog('Player iniciado');
    const ctx = audioContext();
    if (ctx && ctx.state === 'running') this.unlock();
    this.sync.start();
    window.setInterval(() => this.tick(), 1000);
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') void this.requestWakeLock();
    });
  }

  unlock() {
    if (this.unlocked) return;
    this.unlocked = true;
    const ctx = audioContext();
    void ctx?.resume().catch(() => undefined);
    // "Esquenta" a síntese de voz para carregar as vozes
    try {
      window.speechSynthesis?.getVoices();
    } catch {
      /* ignore */
    }
    void this.requestWakeLock();
    this.addLog('Áudio ativado neste notebook');
    this.currentUrl = '';
    this.syncStream();
    void this.playNext();
    this.refreshStatus();
  }

  subscribe(fn: () => void) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  snapshot(): EngineSnapshot {
    return {
      state: this.state,
      unlocked: this.unlocked,
      online: this.online,
      status: this.status,
      detail: this.detail,
      nowJingle: this.current?.label ?? null,
      queueSize: this.queue.length,
      log: this.log,
      cached: this.cached,
      serverNow: this.sync.serverNow(),
    };
  }

  private emit() {
    this.listeners.forEach((fn) => fn());
  }

  private addLog(text: string) {
    this.log = [{ at: Date.now(), text }, ...this.log].slice(0, 25);
    this.emit();
  }

  private async requestWakeLock() {
    try {
      const nav = navigator as Navigator & { wakeLock?: { request: (t: 'screen') => Promise<{ release: () => Promise<void> }> } };
      if (this.unlocked && nav.wakeLock && document.visibilityState === 'visible') {
        this.wakeLock = await nav.wakeLock.request('screen');
      }
    } catch {
      /* sem suporte: tudo bem */
    }
  }

  // ---------- estado vindo do Netlify ----------

  private onState(s: RadioState) {
    const prev = this.state;
    this.state = s;

    if (this.lastSeq === null || this.lastSeq > s.cmdSeq) {
      // Primeira vez (ou banco zerado): não repete comandos antigos.
      this.lastSeq = s.cmdSeq;
    }
    const now = this.sync.serverNow();
    const fresh = s.commands.filter((c) => c.seq > (this.lastSeq as number)).sort((a, b) => a.seq - b.seq);
    for (const cmd of fresh) {
      this.lastSeq = cmd.seq;
      if (now - cmd.at > MAX_CMD_AGE) continue;
      this.handleCommand(cmd, s);
    }
    try {
      localStorage.setItem(SEQ_KEY, String(this.lastSeq));
    } catch {
      /* ignore */
    }

    if (prev && prev.stream.url !== s.stream.url && s.stream.playing) {
      this.addLog(`Rádio trocada: ${s.stream.name || s.stream.url}`);
    }
    if (prev && prev.stream.playing !== s.stream.playing) {
      this.addLog(s.stream.playing ? 'Comando: tocar rádio' : 'Comando: parar rádio');
    }

    this.applyVolumes();
    this.syncStream();
    void this.preload(s);
    this.refreshStatus();
  }

  private handleCommand(cmd: Command, s: RadioState) {
    switch (cmd.type) {
      case 'jingle': {
        const j = s.jingles.find((x) => x.id === cmd.jingleId);
        if (!j) return;
        this.addLog(`${cmd.source === 'agendador' ? 'Agendador' : 'Comando'}: vinheta "${j.name}"`);
        this.enqueue({ kind: 'jingle', jingle: j, source: cmd.source });
        return;
      }
      case 'tts':
        this.addLog(`Comando: aviso falado`);
        this.enqueue({ kind: 'tts', text: cmd.text });
        return;
      case 'stopJingles':
        this.addLog('Comando: parar vinhetas');
        this.queue = [];
        this.current?.stop();
        return;
      case 'reload':
        this.addLog('Comando: recarregar player');
        window.setTimeout(() => window.location.reload(), 500);
        return;
    }
  }

  // ---------- rádio (stream) ----------

  private targetRadioVolume() {
    const v = this.state?.volumes;
    if (!v) return 0.8;
    return this.current ? v.stream * v.duck : v.stream;
  }

  private fadeRadioTo(target: number, ms = 500) {
    window.clearInterval(this.fadeTimer);
    const start = this.radio.volume;
    const steps = 10;
    let i = 0;
    this.fadeTimer = window.setInterval(() => {
      i += 1;
      this.radio.volume = Math.min(1, Math.max(0, start + ((target - start) * i) / steps));
      if (i >= steps) window.clearInterval(this.fadeTimer);
    }, ms / steps);
  }

  private applyVolumes() {
    this.fadeRadioTo(this.targetRadioVolume(), 250);
    if (this.current?.audio && this.state) this.current.audio.volume = this.state.volumes.jingle;
  }

  private syncStream() {
    const s = this.state;
    if (!s) return;
    const want = s.stream.playing ? s.stream.url.trim() : '';
    if (!this.unlocked) return;

    if (!want) {
      this.streamError = null;
      if (this.currentUrl || !this.radio.paused) {
        this.currentUrl = '';
        window.clearTimeout(this.retryTimer);
        this.radio.pause();
        this.radio.removeAttribute('src');
        this.radio.load();
      }
      return;
    }
    if (want !== this.currentUrl) {
      this.currentUrl = want;
      this.retryDelay = 2000;
      this.streamError = null;
      this.startStream();
    }
  }

  private startStream() {
    window.clearTimeout(this.retryTimer);
    if (!this.currentUrl) return;
    this.refreshStatus();
    this.radio.src = this.currentUrl;
    this.radio.volume = this.targetRadioVolume();
    this.lastProgress = { time: 0, at: Date.now() };
    this.radio.play().catch((err: DOMException) => {
      if (err?.name === 'NotAllowedError') {
        this.unlocked = false;
        this.currentUrl = '';
        this.refreshStatus();
      } else if (err?.name !== 'AbortError') {
        this.onStreamFailure(err?.message || 'falha ao tocar');
      }
    });
  }

  private onStreamFailure(reason: string) {
    if (!this.currentUrl || !this.unlocked) return;
    window.clearTimeout(this.retryTimer);
    const secs = Math.round(this.retryDelay / 1000);
    if (!this.streamError) this.addLog(`Rádio caiu (${reason}), tentando reconectar`);
    this.streamError = `Stream caiu (${reason}). Reconectando em ${secs}s…`;
    this.refreshStatus();
    this.retryTimer = window.setTimeout(() => this.startStream(), this.retryDelay);
    this.retryDelay = Math.min(this.retryDelay * 2, 30_000);
  }

  // ---------- vinhetas ----------

  private enqueue(item: QueueItem) {
    if (item.kind === 'jingle' && this.queue.some((q) => q.kind === 'jingle' && q.jingle.id === item.jingle.id)) {
      return;
    }
    this.queue.push(item);
    void this.playNext();
    this.emit();
  }

  private async playNext() {
    if (this.current || !this.unlocked) return;
    const item = this.queue.shift();
    if (!item) {
      this.fadeRadioTo(this.targetRadioVolume(), 800);
      this.refreshStatus();
      return;
    }

    const label = item.kind === 'tts' ? 'Aviso falado' : item.jingle.name;
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      window.clearTimeout(safety);
      this.current = null;
      this.emit();
      window.setTimeout(() => void this.playNext(), 300);
    };
    // Nenhuma vinheta trava a fila por mais de 10 minutos
    const safety = window.setTimeout(finish, 10 * 60_000);

    this.current = { label, stop: finish };
    this.fadeRadioTo(this.targetRadioVolume(), 400);
    this.refreshStatus();

    const vol = this.state?.volumes.jingle ?? 1;

    if (item.kind === 'tts') {
      this.current.stop = playChimeAndSpeak(item.text, vol, finish);
      return;
    }
    const j = item.jingle;
    if (j.kind === 'synth') {
      this.current.stop = playChimeAndSpeak(synthText(j.synthType || 'chime', j.name), vol, finish);
      return;
    }

    const blob = await getAudio(j.id);
    if (done) return;
    if (!blob) {
      this.addLog(`Não consegui baixar "${j.name}"`);
      finish();
      return;
    }
    const url = URL.createObjectURL(blob);
    const audio = new Audio(url);
    audio.volume = vol;
    const end = () => {
      audio.pause();
      URL.revokeObjectURL(url);
      finish();
    };
    audio.onended = end;
    audio.onerror = end;
    this.current = { label, stop: end, audio };
    audio.play().catch(end);
  }

  private async preload(s: RadioState) {
    const files = s.jingles.filter((j) => j.kind === 'file');
    for (const j of files) await getAudio(j.id);
    const keep = new Set(files.map((j) => j.id));
    const keys = await cacheKeys();
    await Promise.all(keys.filter((k) => !keep.has(k)).map((k) => cacheDel(k)));
    const count = files.length;
    if (count !== this.cached) {
      this.cached = count;
      this.emit();
    }
  }

  // ---------- agendador + vigia do stream (a cada 1 s) ----------

  private tick() {
    const s = this.state;
    if (s && this.unlocked) {
      const sch = s.scheduler;
      const now = this.sync.serverNow();
      const retryOk = !this.lastFire || this.lastFire.runAt !== sch.nextRunAt || Date.now() - this.lastFire.at > 15_000;
      if (sch.active && sch.nextRunAt && now >= sch.nextRunAt && rotationOf(s).length > 0 && retryOk) {
        const runAt = sch.nextRunAt;
        this.lastFire = { runAt, at: Date.now() };
        sendAction({ type: 'schedulerFire', runAt })
          .then((resp) => this.sync.accept(resp))
          .catch(() => undefined);
      }

      // Vigia: se deveria estar tocando mas o áudio parou de avançar por 20 s, reconecta.
      if (this.currentUrl && !this.streamError) {
        const t = this.radio.currentTime;
        if (t !== this.lastProgress.time) this.lastProgress = { time: t, at: Date.now() };
        else if (Date.now() - this.lastProgress.at > 20_000) this.onStreamFailure('sem sinal');
      }
    }
    this.emit();
  }

  // ---------- status ----------

  private refreshStatus() {
    const s = this.state;
    let status: PlayerStatusKind;
    let detail: string;
    if (!this.unlocked) {
      status = 'locked';
      detail = 'Aguardando clique para ativar o áudio';
    } else if (this.current) {
      status = 'jingle';
      detail = `Vinheta: ${this.current.label}`;
    } else if (this.currentUrl && this.streamError) {
      status = 'error';
      detail = this.streamError;
    } else if (this.currentUrl) {
      const playing = !this.radio.paused && this.radio.readyState >= 3;
      status = playing ? 'radio' : 'connecting';
      detail = `${playing ? 'No ar' : 'Conectando'}: ${s?.stream.name || this.currentUrl}`;
    } else {
      status = 'idle';
      detail = 'Rádio parada';
    }
    const changed = status !== this.status || detail !== this.detail;
    this.status = status;
    this.detail = detail;
    this.emit();
    if (changed) {
      window.clearTimeout(this.hbTimer);
      this.hbTimer = window.setTimeout(() => void this.sync.ping(), 600);
    }
  }
}
