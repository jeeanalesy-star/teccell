// Importa as rádios favoritas e vinhetas do sistema antigo (Firebase do AI Studio)
// para o banco novo do Netlify. É carregado só quando o botão é usado.
import firebaseConfig from './firebase-antigo.json';
import type { SynthType } from '../../shared/state.ts';
import type { Action } from '../../shared/reducer.ts';

export interface MigrationDeps {
  act: (a: Action) => Promise<boolean>;
  upload: (files: { blob: Blob; name: string }[]) => Promise<void>;
  progress: (msg: string) => void;
}

function dataUrlToBlob(dataUrl: string): Blob {
  const [head, body = ''] = dataUrl.split(';base64,');
  const type = head.split(':')[1] || 'audio/mpeg';
  const raw = atob(body);
  const bytes = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
  return new Blob([bytes], { type });
}

export async function migrateFromFirebase({ act, upload, progress }: MigrationDeps) {
  progress('Conectando ao sistema antigo…');
  const { initializeApp } = await import('firebase/app');
  const { getFirestore, collection, getDocs, doc, getDoc, query, orderBy } = await import('firebase/firestore');

  const app = initializeApp(firebaseConfig, 'antigo');
  const db = firebaseConfig.firestoreDatabaseId
    ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
    : getFirestore(app);

  let favs = 0;
  let vinhetas = 0;

  // 1) Rádios favoritas
  const favSnap = await getDocs(collection(db, 'favorites'));
  for (const d of favSnap.docs) {
    const f = d.data() as { name?: string; url?: string };
    if (f.url) {
      progress(`Importando rádio: ${f.name || f.url}`);
      // ignora erro de "já está nas favoritas"
      if (await act({ type: 'favAdd', name: f.name || '', url: f.url })) favs++;
    }
  }

  // 2) Rádio que estava selecionada
  const st = await getDoc(doc(db, 'appState', 'current'));
  if (st.exists()) {
    const s = st.data() as { streamUrl?: string; radioName?: string };
    if (s.streamUrl) await act({ type: 'setStream', url: s.streamUrl, name: s.radioName || '' });
  }

  // 3) Vinhetas
  const jSnap = await getDocs(collection(db, 'jingles'));
  const docs = jSnap.docs.sort((a, b) =>
    String(a.data().createdAt || '').localeCompare(String(b.data().createdAt || '')),
  );
  for (const d of docs) {
    const j = d.data() as { name?: string; url?: string; hasChunks?: boolean; synthType?: SynthType; isPresetSample?: boolean };
    const name = j.name || 'Vinheta';
    progress(`Importando vinheta: ${name}`);
    try {
      if (j.url?.startsWith('synth:')) {
        await act({ type: 'jingleAddSynth', name, synthType: j.synthType || (j.url.slice(6) as SynthType) || 'chime' });
        vinhetas++;
      } else if (j.url?.startsWith('data:')) {
        await upload([{ blob: dataUrlToBlob(j.url), name }]);
        vinhetas++;
      } else if (j.hasChunks) {
        const chunks = await getDocs(query(collection(db, 'jingles', d.id, 'chunks'), orderBy('index', 'asc')));
        const full = chunks.docs.map((c) => String(c.data().data || '')).join('');
        if (full) {
          await upload([{ blob: dataUrlToBlob(full), name }]);
          vinhetas++;
        }
      }
    } catch (err) {
      progress(`Falhou "${name}": ${(err as Error).message}`);
    }
  }

  return { favs, vinhetas };
}
