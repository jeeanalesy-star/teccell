// Comunicação com o Netlify: comandos (/api/action), envio de áudio (/api/audio)
// e sincronização em tempo real (/api/poll com long polling).
import type { Action } from '../../shared/reducer.ts';
import type { ActionResponse, PlayerHeartbeat, PollResponse, RadioState } from '../../shared/state.ts';

const PIN_KEY = 'teccell-radio-pin';

export const pinStore = {
  get: () => {
    try {
      return localStorage.getItem(PIN_KEY) || '';
    } catch {
      return '';
    }
  },
  set: (pin: string) => {
    try {
      localStorage.setItem(PIN_KEY, pin);
    } catch {
      /* sem armazenamento local */
    }
  },
  clear: () => {
    try {
      localStorage.removeItem(PIN_KEY);
    } catch {
      /* ignore */
    }
  },
};

export class AuthError extends Error {}

async function readJson(r: Response): Promise<ActionResponse> {
  try {
    return (await r.json()) as ActionResponse;
  } catch {
    return { ok: false, now: Date.now(), error: `Erro do servidor (${r.status}).` };
  }
}

export async function sendAction(action: Action, pin = pinStore.get()): Promise<ActionResponse> {
  const r = await fetch('/api/action', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-radio-pin': pin },
    body: JSON.stringify(action),
  });
  const data = await readJson(r);
  if (r.status === 401) throw new AuthError(data.error || 'PIN incorreto.');
  if (!data.ok) throw new Error(data.error || 'Não foi possível salvar.');
  return data;
}

export async function uploadAudio(file: Blob, name: string, pin = pinStore.get()): Promise<ActionResponse> {
  const r = await fetch('/api/audio', {
    method: 'POST',
    headers: {
      'content-type': file.type || 'audio/mpeg',
      'x-radio-pin': pin,
      'x-file-name': encodeURIComponent(name),
    },
    body: file,
  });
  const data = await readJson(r);
  if (r.status === 401) throw new AuthError(data.error || 'PIN incorreto.');
  if (!data.ok) throw new Error(data.error || 'Falha ao enviar o áudio.');
  return data;
}

export const audioUrl = (id: string) => `/api/audio/${encodeURIComponent(id)}`;

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export interface SyncHandlers {
  onState: (s: RadioState) => void;
  onPlayer?: (p: PlayerHeartbeat | null) => void;
  onConnection?: (online: boolean) => void;
  /** Só o notebook envia o sinal de vida. */
  heartbeat?: () => { status: string; detail: string } | null;
}

/**
 * Mantém o estado local igual ao do banco. Usa long polling: a requisição fica
 * aberta no Netlify até algo mudar (máx. ~15 s), e então já volta com o estado novo.
 */
export class RadioSync {
  version = -1;
  /** diferença entre o relógio do servidor e o deste aparelho */
  offset = 0;
  private running = false;
  private ctrl: AbortController | null = null;
  private failures = 0;

  constructor(private h: SyncHandlers) {}

  serverNow() {
    return Date.now() + this.offset;
  }

  start() {
    if (this.running) return;
    this.running = true;
    void this.loop();
    document.addEventListener('visibilitychange', this.onVisible);
    window.addEventListener('online', this.restart);
  }

  stop() {
    this.running = false;
    this.ctrl?.abort();
    document.removeEventListener('visibilitychange', this.onVisible);
    window.removeEventListener('online', this.restart);
  }

  /** Interrompe a espera atual e consulta de novo na hora. */
  restart = () => {
    this.ctrl?.abort();
  };

  private onVisible = () => {
    if (document.visibilityState === 'visible') this.restart();
  };

  /** Aplica o estado que veio na resposta de um comando (fica instantâneo para quem enviou). */
  accept(resp: { now: number; state?: RadioState }) {
    if (typeof resp.now === 'number') this.offset = resp.now - Date.now();
    if (resp.state && resp.state.version >= this.version) {
      this.version = resp.state.version;
      this.h.onState(resp.state);
    }
  }

  /** Envia o sinal de vida imediatamente (ex.: quando o status do notebook muda). */
  async ping() {
    try {
      await this.request(0);
    } catch {
      /* próxima consulta tenta de novo */
    }
  }

  private async request(waitSec: number, signal?: AbortSignal) {
    const params = new URLSearchParams({ v: String(this.version), wait: String(waitSec) });
    const hb = this.h.heartbeat?.();
    if (hb) params.set('hb', JSON.stringify(hb));
    const r = await fetch(`/api/poll?${params}`, { cache: 'no-store', signal });
    if (!r.ok) throw new Error(`poll ${r.status}`);
    const data = (await r.json()) as PollResponse;
    this.offset = data.now - Date.now();
    if (data.changed && data.state && data.state.version >= this.version) {
      this.version = data.state.version;
      this.h.onState(data.state);
    }
    this.h.onPlayer?.(data.player);
    return data;
  }

  private async loop() {
    while (this.running) {
      const started = Date.now();
      this.ctrl = new AbortController();
      const timeout = setTimeout(() => this.ctrl?.abort(), 25_000);
      try {
        const data = await this.request(this.version < 0 ? 0 : 15, this.ctrl.signal);
        this.failures = 0;
        this.h.onConnection?.(true);
        // Se o servidor respondeu rápido sem mudança (não segurou a conexão), espera um pouco
        // para não gastar requisições à toa.
        if (!data.changed && Date.now() - started < 1500) await sleep(2000);
      } catch (err) {
        const aborted = (err as Error)?.name === 'AbortError';
        if (!aborted) {
          this.failures += 1;
          if (this.failures >= 2) this.h.onConnection?.(false);
          await sleep(Math.min(2000 * this.failures, 15_000));
        }
      } finally {
        clearTimeout(timeout);
      }
    }
  }
}
