// Cache local (IndexedDB) dos áudios das vinhetas no notebook:
// baixa uma vez do Netlify e depois toca na hora, mesmo se a internet oscilar.
import { audioUrl } from './api.ts';

const DB_NAME = 'TecCellRadioAudio';
const STORE = 'audios';

let dbPromise: Promise<IDBDatabase> | null = null;

function openDB(): Promise<IDBDatabase> {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    dbPromise.catch(() => {
      dbPromise = null;
    });
  }
  return dbPromise;
}

function run<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T | null> {
  return openDB()
    .then(
      (db) =>
        new Promise<T | null>((resolve) => {
          const req = fn(db.transaction(STORE, mode).objectStore(STORE));
          req.onsuccess = () => resolve((req.result as T) ?? null);
          req.onerror = () => resolve(null);
        }),
    )
    .catch(() => null);
}

export const cacheGet = (id: string) => run<Blob>('readonly', (s) => s.get(id));
export const cachePut = (id: string, blob: Blob) => run('readwrite', (s) => s.put(blob, id));
export const cacheDel = (id: string) => run('readwrite', (s) => s.delete(id));
export const cacheKeys = async () => ((await run<IDBValidKey[]>('readonly', (s) => s.getAllKeys())) || []).map(String);

const inflight = new Map<string, Promise<Blob | null>>();

/** Pega o áudio do cache; se não tiver, baixa do Netlify e guarda. */
export function getAudio(id: string): Promise<Blob | null> {
  const existing = inflight.get(id);
  if (existing) return existing;
  const p = (async () => {
    const cached = await cacheGet(id);
    if (cached && cached.size > 0) return cached;
    try {
      const r = await fetch(audioUrl(id));
      if (!r.ok) return null;
      const blob = await r.blob();
      if (blob.size > 0) await cachePut(id, blob);
      return blob;
    } catch {
      return null;
    }
  })().finally(() => inflight.delete(id));
  inflight.set(id, p);
  return p;
}
