// Vinhetas sintéticas (toque + voz do navegador) e avisos falados digitados no celular.
import type { SynthType } from '../../shared/state.ts';

const SYNTH_TEXT: Record<SynthType, (name: string) => string> = {
  sale: () => 'Atenção clientes TecCell! Confira nossas super ofertas em smartphones, capas e películas em destaque hoje!',
  announcement: () =>
    'Aviso ao público. Procure um de nossos atendentes na loja TecCell para tirar suas dúvidas e aproveitar os serviços.',
  promo: () => 'Rádio TecCell Indoor. A melhor tecnologia e os melhores preços perto de você!',
  chime: (name) => `Rádio TecCell. ${name}.`,
  custom: (name) => name,
};

export const synthText = (type: SynthType, name: string) => (SYNTH_TEXT[type] || SYNTH_TEXT.chime)(name);

let sharedCtx: AudioContext | null = null;
export function audioContext(): AudioContext | null {
  const Ctx =
    window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return null;
  if (!sharedCtx || sharedCtx.state === 'closed') sharedCtx = new Ctx();
  return sharedCtx;
}

function pickVoice(): SpeechSynthesisVoice | null {
  const voices = window.speechSynthesis?.getVoices?.() || [];
  return (
    voices.find((v) => v.lang === 'pt-BR' && /google|microsoft|maria|francisca|luciana/i.test(v.name)) ||
    voices.find((v) => v.lang?.toLowerCase().startsWith('pt-br')) ||
    voices.find((v) => v.lang?.toLowerCase().startsWith('pt')) ||
    null
  );
}

/** Toca o "plim" e depois fala o texto. Retorna uma função para interromper. */
export function playChimeAndSpeak(text: string, volume: number, onEnd: () => void): () => void {
  let finished = false;
  const timers: number[] = [];
  const finish = () => {
    if (finished) return;
    finished = true;
    timers.forEach((t) => clearTimeout(t));
    onEnd();
  };

  try {
    const ctx = audioContext();
    let chimeSec = 0;
    if (ctx) {
      void ctx.resume().catch(() => undefined);
      const main = ctx.createGain();
      main.gain.value = Math.max(0.0001, volume);
      main.connect(ctx.destination);
      const notes = [523.25, 659.25, 783.99, 1046.5];
      const t0 = ctx.currentTime + 0.05;
      notes.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        const t = t0 + i * 0.12;
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, t);
        g.gain.setValueAtTime(0.01, t);
        g.gain.exponentialRampToValueAtTime(0.4, t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.4);
        osc.connect(g);
        g.connect(main);
        osc.start(t);
        osc.stop(t + 0.45);
      });
      chimeSec = notes.length * 0.12 + 0.5;
    }

    const speak = () => {
      if (!('speechSynthesis' in window) || !text.trim()) {
        timers.push(window.setTimeout(finish, 800));
        return;
      }
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'pt-BR';
      const voice = pickVoice();
      if (voice) u.voice = voice;
      u.rate = 1.02;
      u.volume = Math.min(1, volume);
      u.onend = finish;
      u.onerror = finish;
      window.speechSynthesis.speak(u);
      // Segurança: alguns navegadores não disparam onend
      timers.push(window.setTimeout(finish, 15_000 + text.length * 120));
    };
    timers.push(window.setTimeout(speak, chimeSec * 1000));
  } catch {
    timers.push(window.setTimeout(finish, 0));
  }

  return () => {
    try {
      window.speechSynthesis?.cancel();
    } catch {
      /* ignore */
    }
    finish();
  };
}
