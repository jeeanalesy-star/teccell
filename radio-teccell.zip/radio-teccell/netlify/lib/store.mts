// Acesso ao banco do próprio Netlify (Netlify Blobs).
// Store "radio": chave "state" (estado completo), "player" (sinal de vida do notebook), "auth" (PIN).
// Store "audios": um blob por vinheta enviada.

import { getStore } from '@netlify/blobs';
import { createHash, timingSafeEqual } from 'node:crypto';
import { RadioState, normalizeState } from '../../shared/state.ts';

export const radioStore = () => getStore({ name: 'radio', consistency: 'strong' });
export const audioStore = () => getStore({ name: 'audios', consistency: 'strong' });

export async function readState(): Promise<RadioState> {
  const raw = await radioStore().get('state', { type: 'json' });
  return normalizeState(raw);
}

export async function writeState(s: RadioState, now: number): Promise<RadioState> {
  s.version += 1;
  s.updatedAt = now;
  await radioStore().setJSON('state', s, { metadata: { version: s.version } });
  return s;
}

export const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
  });

const sha = (v: string) => createHash('sha256').update(`teccell-radio:${v}`).digest();

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/**
 * Confere o PIN enviado no cabeçalho "x-radio-pin".
 * - Se a variável de ambiente RADIO_PIN existir no Netlify, ela manda.
 * - Senão, o primeiro PIN usado (mín. 4 dígitos) é cadastrado e passa a valer.
 */
export async function checkPin(req: Request): Promise<{ ok: boolean; created?: boolean; error?: string }> {
  const pin = (req.headers.get('x-radio-pin') || '').trim();
  const envPin = (process.env.RADIO_PIN || '').trim();

  if (envPin) {
    const ok = pin.length === envPin.length && timingSafeEqual(sha(pin), sha(envPin));
    if (!ok) await sleep(700);
    return ok ? { ok } : { ok, error: 'PIN incorreto.' };
  }

  const store = radioStore();
  const saved = (await store.get('auth', { type: 'json' })) as { hash?: string } | null;
  if (!saved?.hash) {
    if (pin.length < 4) return { ok: false, error: 'Crie um PIN com pelo menos 4 números.' };
    await store.setJSON('auth', { hash: sha(pin).toString('hex'), createdAt: Date.now() });
    return { ok: true, created: true };
  }
  const ok = timingSafeEqual(sha(pin), Buffer.from(saved.hash, 'hex'));
  if (!ok) await sleep(700);
  return ok ? { ok } : { ok, error: 'PIN incorreto.' };
}
