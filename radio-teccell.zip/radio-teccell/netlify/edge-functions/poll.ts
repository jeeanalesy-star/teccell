// GET /api/poll?v=<versão>&wait=<segundos>&hb=<json>
// "Long polling": segura a conexão até o estado mudar (ou até `wait` segundos).
// Assim o notebook recebe os comandos em ~1 s, gastando poucas requisições do plano grátis.
// Roda como Edge Function (cobrada só como requisição, sem custo de "compute").
import { getStore } from '@netlify/blobs';
import { defaultState, normalizeState } from '../../shared/state.ts';

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

const STATUS = ['locked', 'idle', 'connecting', 'radio', 'jingle', 'error'];

export default async (req: Request) => {
  const url = new URL(req.url);
  const since = Number(url.searchParams.get('v') ?? '-1');
  const waitSec = Math.max(0, Math.min(Number(url.searchParams.get('wait') ?? '0') || 0, 20));
  const hb = url.searchParams.get('hb');

  const store = getStore({ name: 'radio', consistency: 'strong' });

  // Sinal de vida do notebook (para o celular saber se ele está ligado e o que está tocando)
  if (hb) {
    try {
      const info = JSON.parse(hb.slice(0, 400)) as { status?: string; detail?: string };
      await store.setJSON('player', {
        lastSeen: Date.now(),
        status: STATUS.includes(String(info.status)) ? info.status : 'idle',
        detail: String(info.detail || '').slice(0, 160),
      });
    } catch {
      /* ignora sinal inválido */
    }
  }

  const currentVersion = async () => {
    const meta = await store.getMetadata('state');
    return meta ? Number((meta.metadata as Record<string, unknown>)?.version ?? 0) : 0;
  };

  const deadline = Date.now() + waitSec * 1000;
  let version = await currentVersion();
  while (version === since && Date.now() < deadline) {
    await sleep(900);
    version = await currentVersion();
  }

  const changed = version !== since;
  let state;
  if (changed) {
    const raw = await store.get('state', { type: 'json' });
    state = raw ? normalizeState(raw) : defaultState();
    version = state.version;
  }
  const player = (await store.get('player', { type: 'json' })) ?? null;

  return new Response(JSON.stringify({ now: Date.now(), version, changed, state, player }), {
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
  });
};

export const config = { path: '/api/poll' };
