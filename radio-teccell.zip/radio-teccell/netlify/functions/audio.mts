// POST /api/audio       — envia um arquivo de vinheta (corpo = bytes do áudio)
// GET  /api/audio/:id   — baixa o áudio (o notebook guarda em cache e só baixa uma vez)
import { reduce } from '../../shared/reducer.ts';
import { MAX_UPLOAD_BYTES } from '../../shared/state.ts';
import { audioStore, checkPin, json, readState, writeState } from '../lib/store.mts';

interface Ctx {
  params?: Record<string, string>;
}

export default async (req: Request, context: Ctx) => {
  const id = context?.params?.id;

  if (req.method === 'GET' && id) {
    const found = await audioStore().getWithMetadata(id, { type: 'arrayBuffer' });
    if (!found) return new Response('Áudio não encontrado', { status: 404 });
    const mime = String((found.metadata as Record<string, unknown>)?.mime || 'audio/mpeg');
    return new Response(found.data as ArrayBuffer, {
      headers: {
        'content-type': mime,
        'cache-control': 'public, max-age=31536000, immutable',
      },
    });
  }

  if (req.method === 'POST' && !id) {
    const auth = await checkPin(req);
    if (!auth.ok) return json({ ok: false, now: Date.now(), error: auth.error }, 401);

    const buf = await req.arrayBuffer();
    if (!buf.byteLength) return json({ ok: false, error: 'Arquivo vazio.' }, 400);
    if (buf.byteLength > MAX_UPLOAD_BYTES) {
      return json({ ok: false, error: 'Arquivo maior que 5 MB. Converta para MP3 mais leve.' }, 413);
    }

    const mime = (req.headers.get('content-type') || 'audio/mpeg').split(';')[0];
    let name = 'Vinheta';
    try {
      name = decodeURIComponent(req.headers.get('x-file-name') || 'Vinheta');
    } catch {
      /* nome inválido: usa o padrão */
    }

    const audioId = crypto.randomUUID();
    await audioStore().set(audioId, buf, { metadata: { mime, name } });

    const now = Date.now();
    let state = await readState();
    reduce(state, { type: 'jingleAddFile', id: audioId, name, mime, size: buf.byteLength }, now);
    state = await writeState(state, now);
    return json({ ok: true, now, state });
  }

  return json({ ok: false, error: 'Método não permitido.' }, 405);
};

export const config = { path: ['/api/audio', '/api/audio/:id'] };
