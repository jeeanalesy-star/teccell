// POST /api/action  — recebe um comando do celular (ou do notebook) e grava no banco.
import { Action, PUBLIC_ACTIONS, reduce } from '../../shared/reducer.ts';
import { audioStore, checkPin, json, readState, writeState } from '../lib/store.mts';

export default async (req: Request) => {
  if (req.method !== 'POST') return json({ ok: false, error: 'Método não permitido.' }, 405);

  let action: Action;
  try {
    action = (await req.json()) as Action;
  } catch {
    return json({ ok: false, error: 'Requisição inválida.' }, 400);
  }
  if (!action || typeof action.type !== 'string') {
    return json({ ok: false, error: 'Requisição inválida.' }, 400);
  }

  let created = false;
  if (!PUBLIC_ACTIONS.includes(action.type)) {
    const auth = await checkPin(req);
    if (!auth.ok) return json({ ok: false, now: Date.now(), error: auth.error }, 401);
    created = !!auth.created;
  }

  const now = Date.now();
  let state = await readState();
  const result = reduce(state, action, now);
  if (result.error) return json({ ok: false, now, error: result.error, state }, 400);

  if (result.changed) state = await writeState(state, now);

  if (result.deletedAudio.length) {
    const audios = audioStore();
    await Promise.all(result.deletedAudio.map((id) => audios.delete(id).catch(() => undefined)));
  }

  return json({ ok: true, now, state, created });
};

export const config = { path: '/api/action' };
