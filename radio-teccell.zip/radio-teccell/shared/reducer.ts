// Todas as alterações possíveis no estado da rádio.
// Roda no servidor (função /api/action). É puro: recebe o estado e devolve o novo.

import {
  Command,
  Jingle,
  MAX_COMMANDS,
  RadioState,
  SynthType,
  rotationOf,
} from './state.ts';

export type Action =
  | { type: 'auth' }
  | { type: 'play'; url?: string; name?: string }
  | { type: 'stop' }
  | { type: 'setStream'; url: string; name?: string }
  | { type: 'volume'; stream?: number; jingle?: number; duck?: number }
  | { type: 'favAdd'; name: string; url: string }
  | { type: 'favDel'; id: string }
  | { type: 'favClear' }
  | { type: 'jingleAddFile'; id: string; name: string; mime: string; size: number }
  | { type: 'jingleAddSynth'; name: string; synthType: SynthType }
  | { type: 'jingleRename'; id: string; name: string }
  | { type: 'jingleDel'; id: string }
  | { type: 'jingleClear' }
  | { type: 'jingleRotation'; id: string; inRotation: boolean }
  | { type: 'jingleMove'; id: string; dir: -1 | 1 }
  | { type: 'jinglePlay'; id: string }
  | { type: 'stopJingles' }
  | { type: 'tts'; text: string }
  | { type: 'schedulerToggle'; active?: boolean }
  | { type: 'schedulerInterval'; minutes: number }
  | { type: 'schedulerSetNext'; index: number }
  | { type: 'schedulerPlayNext' }
  /** enviado pelo notebook quando chega a hora da vinheta automática (não exige PIN) */
  | { type: 'schedulerFire'; runAt: number }
  | { type: 'reloadPlayer' };

export const PUBLIC_ACTIONS: Action['type'][] = ['schedulerFire'];

export interface ReduceResult {
  changed: boolean;
  error?: string;
  /** ids de áudios que devem ser apagados do armazenamento */
  deletedAudio: string[];
}

const clamp01 = (n: unknown, fallback: number) => {
  const v = typeof n === 'number' && Number.isFinite(n) ? n : fallback;
  return Math.min(1, Math.max(0, v));
};

const str = (v: unknown, max = 500) => (typeof v === 'string' ? v.trim().slice(0, max) : '');

const newId = () =>
  (globalThis.crypto && 'randomUUID' in globalThis.crypto
    ? globalThis.crypto.randomUUID()
    : `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`);

type NewCommand =
  | { type: 'jingle'; jingleId: string; source: 'manual' | 'agendador' }
  | { type: 'tts'; text: string }
  | { type: 'stopJingles' }
  | { type: 'reload' };

function pushCommand(s: RadioState, cmd: NewCommand, now: number) {
  s.cmdSeq += 1;
  s.commands.push({ ...cmd, seq: s.cmdSeq, at: now } as Command);
  if (s.commands.length > MAX_COMMANDS) s.commands = s.commands.slice(-MAX_COMMANDS);
}

function resetTimer(s: RadioState, now: number) {
  s.scheduler.nextRunAt = s.scheduler.active ? now + s.scheduler.intervalMinutes * 60_000 : null;
}

function fixNextIndex(s: RadioState) {
  const len = rotationOf(s).length;
  s.scheduler.nextIndex = len > 0 ? ((s.scheduler.nextIndex % len) + len) % len : 0;
}

/** Toca a próxima da rotação: cria o comando e avança o ponteiro. */
function fireRotation(s: RadioState, now: number, source: 'manual' | 'agendador') {
  const rot = rotationOf(s);
  if (rot.length > 0) {
    const idx = s.scheduler.nextIndex % rot.length;
    pushCommand(s, { type: 'jingle', jingleId: rot[idx].id, source }, now);
    s.scheduler.nextIndex = (idx + 1) % rot.length;
  }
  resetTimer(s, now);
}

/** Aplica a ação no estado (modifica `s`). */
export function reduce(s: RadioState, a: Action, now: number): ReduceResult {
  const res: ReduceResult = { changed: true, deletedAudio: [] };
  const fail = (error: string): ReduceResult => ({ changed: false, error, deletedAudio: [] });

  switch (a.type) {
    case 'auth':
      return { changed: false, deletedAudio: [] };

    case 'play': {
      const url = a.url !== undefined ? str(a.url, 2000) : s.stream.url;
      if (!url) return fail('Informe a URL da rádio.');
      s.stream.url = url;
      if (a.name !== undefined) s.stream.name = str(a.name, 120);
      s.stream.playing = true;
      return res;
    }

    case 'stop':
      s.stream.playing = false;
      return res;

    case 'setStream':
      s.stream.url = str(a.url, 2000);
      if (a.name !== undefined) s.stream.name = str(a.name, 120);
      return res;

    case 'volume':
      if (a.stream !== undefined) s.volumes.stream = clamp01(a.stream, s.volumes.stream);
      if (a.jingle !== undefined) s.volumes.jingle = clamp01(a.jingle, s.volumes.jingle);
      if (a.duck !== undefined) s.volumes.duck = clamp01(a.duck, s.volumes.duck);
      return res;

    case 'favAdd': {
      const url = str(a.url, 2000);
      if (!url) return fail('Informe a URL da rádio.');
      if (s.favorites.some((f) => f.url === url)) return fail('Essa rádio já está nas favoritas.');
      s.favorites.push({ id: newId(), name: str(a.name, 120) || `Rádio ${s.favorites.length + 1}`, url });
      return res;
    }

    case 'favDel':
      s.favorites = s.favorites.filter((f) => f.id !== a.id);
      return res;

    case 'favClear':
      s.favorites = [];
      return res;

    case 'jingleAddFile': {
      const j: Jingle = {
        id: str(a.id, 100),
        name: str(a.name, 120) || 'Vinheta',
        kind: 'file',
        mime: str(a.mime, 100) || 'audio/mpeg',
        size: typeof a.size === 'number' ? a.size : 0,
        createdAt: now,
        inRotation: true,
      };
      if (!j.id) return fail('Áudio inválido.');
      s.jingles.push(j);
      return res;
    }

    case 'jingleAddSynth':
      s.jingles.push({
        id: newId(),
        name: str(a.name, 120) || 'Vinheta',
        kind: 'synth',
        synthType: a.synthType || 'chime',
        createdAt: now,
        inRotation: true,
      });
      return res;

    case 'jingleRename': {
      const j = s.jingles.find((x) => x.id === a.id);
      const name = str(a.name, 120);
      if (!j || !name) return fail('Vinheta não encontrada.');
      j.name = name;
      return res;
    }

    case 'jingleDel': {
      const j = s.jingles.find((x) => x.id === a.id);
      if (!j) return fail('Vinheta não encontrada.');
      s.jingles = s.jingles.filter((x) => x.id !== a.id);
      if (j.kind === 'file') res.deletedAudio.push(j.id);
      fixNextIndex(s);
      return res;
    }

    case 'jingleClear':
      res.deletedAudio = s.jingles.filter((j) => j.kind === 'file').map((j) => j.id);
      s.jingles = [];
      s.scheduler.nextIndex = 0;
      return res;

    case 'jingleRotation': {
      const j = s.jingles.find((x) => x.id === a.id);
      if (!j) return fail('Vinheta não encontrada.');
      j.inRotation = !!a.inRotation;
      fixNextIndex(s);
      return res;
    }

    case 'jingleMove': {
      const i = s.jingles.findIndex((x) => x.id === a.id);
      const dir = a.dir === -1 ? -1 : 1;
      let k = i + dir;
      // Se está na rotação, troca de lugar com a vizinha que também está na rotação
      if (i >= 0 && s.jingles[i].inRotation) {
        while (k >= 0 && k < s.jingles.length && !s.jingles[k].inRotation) k += dir;
      }
      if (i < 0 || k < 0 || k >= s.jingles.length) return { changed: false, deletedAudio: [] };
      [s.jingles[i], s.jingles[k]] = [s.jingles[k], s.jingles[i]];
      fixNextIndex(s);
      return res;
    }

    case 'jinglePlay': {
      const j = s.jingles.find((x) => x.id === a.id);
      if (!j) return fail('Vinheta não encontrada.');
      pushCommand(s, { type: 'jingle', jingleId: j.id, source: 'manual' }, now);
      return res;
    }

    case 'stopJingles':
      pushCommand(s, { type: 'stopJingles' }, now);
      return res;

    case 'tts': {
      const text = str(a.text, 400);
      if (!text) return fail('Digite o texto do aviso.');
      pushCommand(s, { type: 'tts', text }, now);
      return res;
    }

    case 'schedulerToggle':
      s.scheduler.active = a.active !== undefined ? !!a.active : !s.scheduler.active;
      resetTimer(s, now);
      return res;

    case 'schedulerInterval': {
      const m = Math.round(Number(a.minutes));
      if (!Number.isFinite(m) || m < 1 || m > 720) return fail('Intervalo deve ser entre 1 e 720 minutos.');
      s.scheduler.intervalMinutes = m;
      resetTimer(s, now);
      return res;
    }

    case 'schedulerSetNext':
      s.scheduler.nextIndex = Math.max(0, Math.floor(Number(a.index) || 0));
      fixNextIndex(s);
      return res;

    case 'schedulerPlayNext':
      fireRotation(s, now, 'manual');
      return res;

    case 'schedulerFire':
      // Idempotente: só dispara se o horário pedido ainda for o agendado
      // (evita disparo duplo se o notebook repetir o pedido).
      if (!s.scheduler.active || s.scheduler.nextRunAt !== a.runAt || now < a.runAt - 5_000) {
        return { changed: false, deletedAudio: [] };
      }
      fireRotation(s, now, 'agendador');
      return res;

    case 'reloadPlayer':
      pushCommand(s, { type: 'reload' }, now);
      return res;

    default:
      return fail('Ação desconhecida.');
  }
}
