// Tipos e estado padrão compartilhados entre o site (celular/notebook)
// e as funções do Netlify. Sem dependências: roda no Node, no Deno (edge) e no navegador.

export type SynthType = 'chime' | 'announcement' | 'sale' | 'promo' | 'custom';

export interface Favorite {
  id: string;
  name: string;
  url: string;
}

export interface Jingle {
  id: string;
  name: string;
  /** 'file' = áudio enviado (fica no Netlify Blobs); 'synth' = vinheta gerada por voz sintética */
  kind: 'file' | 'synth';
  synthType?: SynthType;
  mime?: string;
  size?: number;
  createdAt: number;
  /** Se participa da rotação automática do agendador */
  inRotation: boolean;
}

interface CommandBase {
  seq: number;
  /** horário do servidor (ms) em que o comando foi criado */
  at: number;
}

export type Command =
  | (CommandBase & { type: 'jingle'; jingleId: string; source: 'manual' | 'agendador' })
  | (CommandBase & { type: 'tts'; text: string })
  | (CommandBase & { type: 'stopJingles' })
  | (CommandBase & { type: 'reload' });

export interface RadioState {
  version: number;
  updatedAt: number;
  stream: { url: string; name: string; playing: boolean };
  volumes: { stream: number; jingle: number; duck: number };
  scheduler: {
    active: boolean;
    intervalMinutes: number;
    nextIndex: number;
    /** horário do servidor (ms) da próxima vinheta automática */
    nextRunAt: number | null;
  };
  favorites: Favorite[];
  jingles: Jingle[];
  commands: Command[];
  cmdSeq: number;
}

export type PlayerStatusKind = 'locked' | 'idle' | 'connecting' | 'radio' | 'jingle' | 'error';

export interface PlayerHeartbeat {
  lastSeen: number;
  status: PlayerStatusKind;
  detail: string;
}

export interface PollResponse {
  now: number;
  version: number;
  changed: boolean;
  state?: RadioState;
  player: PlayerHeartbeat | null;
}

export interface ActionResponse {
  ok: boolean;
  now: number;
  error?: string;
  state?: RadioState;
  created?: boolean;
}

export const MAX_COMMANDS = 30;
export const MAX_UPLOAD_BYTES = 5 * 1024 * 1024; // limite seguro do corpo das funções do Netlify (6 MB)

export function defaultState(): RadioState {
  return {
    version: 0,
    updatedAt: 0,
    stream: { url: '', name: '', playing: false },
    volumes: { stream: 0.8, jingle: 1, duck: 0.2 },
    scheduler: { active: false, intervalMinutes: 3, nextIndex: 0, nextRunAt: null },
    favorites: [],
    jingles: [
      {
        id: 'synth-promo',
        name: 'Vinheta Oficial TecCell',
        kind: 'synth',
        synthType: 'promo',
        createdAt: 1,
        inRotation: true,
      },
      {
        id: 'synth-sale',
        name: 'Super Oferta de Celulares',
        kind: 'synth',
        synthType: 'sale',
        createdAt: 2,
        inRotation: true,
      },
    ],
    commands: [],
    cmdSeq: 0,
  };
}

/** Garante que um estado lido do banco tenha todos os campos (para versões futuras/antigas). */
export function normalizeState(raw: unknown): RadioState {
  const d = defaultState();
  if (!raw || typeof raw !== 'object') return d;
  const r = raw as Partial<RadioState>;
  return {
    version: typeof r.version === 'number' ? r.version : 0,
    updatedAt: typeof r.updatedAt === 'number' ? r.updatedAt : 0,
    stream: { ...d.stream, ...(r.stream || {}) },
    volumes: { ...d.volumes, ...(r.volumes || {}) },
    scheduler: { ...d.scheduler, ...(r.scheduler || {}) },
    favorites: Array.isArray(r.favorites) ? r.favorites : [],
    jingles: Array.isArray(r.jingles) ? r.jingles : d.jingles,
    commands: Array.isArray(r.commands) ? r.commands : [],
    cmdSeq: typeof r.cmdSeq === 'number' ? r.cmdSeq : 0,
  };
}

export function rotationOf(s: RadioState): Jingle[] {
  return s.jingles.filter((j) => j.inRotation);
}
